package expo.modules.usagestats

import android.Manifest
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

/**
 * Reads how long specific apps were in the foreground, using Android's
 * UsageStatsManager. Requires the user to enable "Usage access" for this app.
 * Only the package names passed in are read; nothing leaves the device.
 */
class UsageStatsModule : Module() {
  private val context: Context
    get() = appContext.reactContext ?: throw IllegalStateException("React context is not available")

  private fun permissionGranted(): Boolean {
    val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
    } else {
      @Suppress("DEPRECATION")
      appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
    }
    return if (mode == AppOpsManager.MODE_DEFAULT) {
      context.checkCallingOrSelfPermission(Manifest.permission.PACKAGE_USAGE_STATS) == PackageManager.PERMISSION_GRANTED
    } else {
      mode == AppOpsManager.MODE_ALLOWED
    }
  }

  override fun definition() = ModuleDefinition {
    Name("UsageStats")

    Function("hasPermission") {
      permissionGranted()
    }

    /** Minutes each package was in the foreground during the last `days` days. */
    Function("getForegroundMinutes") { packageNames: List<String>, days: Int ->
      val result = mutableMapOf<String, Double>()
      if (permissionGranted()) {
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val start = end - days.toLong() * 24L * 60L * 60L * 1000L
        val stats = usm.queryAndAggregateUsageStats(start, end)
        for (pkg in packageNames) {
          val ms = stats[pkg]?.totalTimeInForeground ?: 0L
          result[pkg] = ms / 60000.0
        }
      }
      result
    }
  }
}
