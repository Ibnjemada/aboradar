import { requireOptionalNativeModule } from 'expo';
import { Linking, Platform } from 'react-native';

interface UsageStatsNative {
  hasPermission(): boolean;
  getForegroundMinutes(packageNames: string[], days: number): Record<string, number>;
}

const Native = Platform.OS === 'android' ? requireOptionalNativeModule<UsageStatsNative>('UsageStats') : null;

/** True on Android builds that include the native module. */
export function usageMeasuringAvailable(): boolean {
  return Native != null;
}

export function hasUsagePermission(): boolean {
  try {
    return Native?.hasPermission() ?? false;
  } catch {
    return false;
  }
}

export function getForegroundMinutes(packageNames: string[], days = 30): Record<string, number> | null {
  if (!Native || packageNames.length === 0) return null;
  try {
    if (!Native.hasPermission()) return null;
    return Native.getForegroundMinutes(packageNames, days);
  } catch {
    return null;
  }
}

/** Opens Android's "Usage access" settings, where the user can allow Abo Radar. */
export async function openUsageSettings(): Promise<void> {
  try {
    await Linking.sendIntent('android.settings.USAGE_ACCESS_SETTINGS');
  } catch {
    await Linking.openSettings();
  }
}
