import { StatusBar } from 'expo-status-bar';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, AppState, Modal, View } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { applyDueChanges } from './src/calc';
import { FORCE_PREMIUM_FOR_TESTING } from './src/config';
import {
  acceptAnnouncement,
  dismissAnnouncement,
  PendingAnnouncement,
  pendingAnnouncements,
  PriceFeed,
} from './src/catalog';
import { BUNDLED_FEED, loadFeed } from './src/feed';
import { rescheduleAll, setupNotifications } from './src/notifications';
import { initPurchases } from './src/premium';
import { AdvisorScreen } from './src/screens/AdvisorScreen';
import { EditScreen } from './src/screens/EditScreen';
import { HomeScreen } from './src/screens/HomeScreen';
import { PremiumScreen } from './src/screens/PremiumScreen';
import { loadPremiumCache, loadSubscriptions, savePremiumCache, saveSubscriptions } from './src/storage';
import { useTheme } from './src/theme';
import { FREE_LIMIT, Subscription } from './src/types';

type Sheet =
  | { kind: 'none' }
  | { kind: 'edit'; sub: Subscription | null }
  | { kind: 'premium'; reason?: 'limit' | 'advisor' }
  | { kind: 'advisor' };

export default function App() {
  const c = useTheme();
  const [loaded, setLoaded] = useState(false);
  const [subs, setSubs] = useState<Subscription[]>([]);
  const [feed, setFeed] = useState<PriceFeed>(BUNDLED_FEED);
  const [isPremium, setIsPremium] = useState(false);
  const [sheet, setSheet] = useState<Sheet>({ kind: 'none' });
  const subsRef = useRef<Subscription[]>([]);

  const persist = useCallback(async (next: Subscription[]) => {
    subsRef.current = next;
    setSubs(next);
    await saveSubscriptions(next);
    rescheduleAll(next);
  }, []);

  useEffect(() => {
    (async () => {
      const [stored, cachedPremium] = await Promise.all([loadSubscriptions(), loadPremiumCache()]);
      // Price changes whose date has arrived become the current price.
      const due = applyDueChanges(stored);
      subsRef.current = due.subs;
      setSubs(due.subs);
      setIsPremium(FORCE_PREMIUM_FOR_TESTING || cachedPremium);
      setLoaded(true);
      if (due.changed) await saveSubscriptions(due.subs);
      rescheduleAll(due.subs);

      loadFeed().then(setFeed);

      const storePremium = await initPurchases();
      if (storePremium !== null && storePremium !== cachedPremium) {
        setIsPremium(FORCE_PREMIUM_FOR_TESTING || storePremium);
        savePremiumCache(storePremium);
      }
    })();

    // The app can stay open for days: re-check due price changes when it comes back.
    const listener = AppState.addEventListener('change', (state) => {
      if (state !== 'active') return;
      const due = applyDueChanges(subsRef.current);
      if (due.changed) persist(due.subs);
    });
    return () => listener.remove();
  }, [persist]);

  const pending = useMemo(() => pendingAnnouncements(subs, feed), [subs, feed]);

  const updateSub = (sub: Subscription) => persist(subs.map((s) => (s.id === sub.id ? sub : s)));

  const openAdd = () => {
    if (!isPremium && subs.length >= FREE_LIMIT) setSheet({ kind: 'premium', reason: 'limit' });
    else setSheet({ kind: 'edit', sub: null });
  };

  const openAdvisor = () => {
    setSheet(isPremium ? { kind: 'advisor' } : { kind: 'premium', reason: 'advisor' });
  };

  const handleSave = async (sub: Subscription) => {
    const exists = subs.some((s) => s.id === sub.id);
    const next = exists ? subs.map((s) => (s.id === sub.id ? sub : s)) : [...subs, sub];
    setSheet({ kind: 'none' });
    await persist(next);
    // Ask for notification permission after the first save, when the value is clear.
    if (!exists && sub.remindDaysBefore >= 0 && subs.length === 0) {
      const granted = await setupNotifications();
      if (granted) rescheduleAll(next);
    }
  };

  const handleDelete = async (id: string) => {
    setSheet({ kind: 'none' });
    await persist(subs.filter((s) => s.id !== id));
  };

  const handleAccept = (p: PendingAnnouncement) => updateSub(acceptAnnouncement(p.sub, p.announcement));
  const handleIgnore = (p: PendingAnnouncement) => updateSub(dismissAnnouncement(p.sub, p.announcement));

  const handleUnlocked = () => {
    const wasAdvisor = sheet.kind === 'premium' && sheet.reason === 'advisor';
    setIsPremium(true);
    savePremiumCache(true);
    setSheet(wasAdvisor ? { kind: 'advisor' } : { kind: 'none' });
  };

  if (!loaded) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: c.bg }}>
        <ActivityIndicator color={c.primary} />
      </View>
    );
  }

  return (
    <SafeAreaProvider>
      <StatusBar style="light" />
      <HomeScreen
        subs={subs}
        feed={feed}
        pending={pending}
        isPremium={isPremium}
        onAdd={openAdd}
        onEdit={(sub) => setSheet({ kind: 'edit', sub })}
        onOpenPremium={() => setSheet({ kind: 'premium' })}
        onOpenAdvisor={openAdvisor}
        onAcceptAnnouncement={handleAccept}
        onIgnoreAnnouncement={handleIgnore}
      />

      <Modal
        visible={sheet.kind !== 'none'}
        animationType="slide"
        statusBarTranslucent
        navigationBarTranslucent
        onRequestClose={() => setSheet({ kind: 'none' })}
      >
        <SafeAreaProvider>
          <StatusBar style="auto" />
          {sheet.kind === 'edit' && (
            <EditScreen
              initial={sheet.sub}
              feed={feed}
              onSave={handleSave}
              onDelete={handleDelete}
              onClose={() => setSheet({ kind: 'none' })}
            />
          )}
          {sheet.kind === 'premium' && (
            <PremiumScreen
              isPremium={isPremium}
              reason={sheet.reason}
              onUnlocked={handleUnlocked}
              onClose={() => setSheet({ kind: 'none' })}
            />
          )}
          {sheet.kind === 'advisor' && (
            <AdvisorScreen subs={subs} feed={feed} onUpdateSub={updateSub} onClose={() => setSheet({ kind: 'none' })} />
          )}
        </SafeAreaProvider>
      </Modal>
    </SafeAreaProvider>
  );
}
