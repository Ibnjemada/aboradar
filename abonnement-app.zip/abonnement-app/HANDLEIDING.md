# Abo Radar – van code naar Google Play

Abo Radar houdt je abonnementen bij, laat zien wat je per maand en per jaar betaalt, en stuurt een herinnering vóór elke afschrijving. Daarnaast:

- **Prijswijzigingen**: elke prijsverhoging of -verlaging wordt bewaard en getoond (↑ rood, ↓ groen). Aangekondigde wijzigingen kun je vooraf invullen; de app waarschuwt een week van tevoren en past de prijs op de ingangsdatum automatisch aan. Via jouw online prijslijst (stap 8) krijgen gebruikers aankondigingen ook vanzelf binnen.
- **Streaming-advies** (Premium): laat per streamingdienst zien hoeveel je hem gebruikt en welke series en films van je kijklijst erop staan. De app berekent welke combinatie je moet houden om alles te kunnen zien, en hoeveel je bespaart met opzeggen.

Gratis tot 5 abonnementen; daarna eenmalig Premium.

Dit stappenplan gaat ervan uit dat je geen programmeur bent. Reken op een paar avonden werk, plus 14 dagen verplichte testperiode bij Google.

---

## Wat je nodig hebt

| Wat | Kosten |
|---|---|
| Een computer (Windows of Mac) | – |
| [Node.js](https://nodejs.org) (de "LTS"-versie) | gratis |
| Een [Expo-account](https://expo.dev/signup) – bouwt de app voor je in de cloud | gratis (genoeg builds per maand) |
| Een [Google Play-ontwikkelaarsaccount](https://play.google.com/console/signup) | eenmalig $25 |
| Een [RevenueCat-account](https://www.revenuecat.com) – regelt de betaling voor Premium | gratis tot $2.500 omzet per maand |
| Een [GitHub-account](https://github.com/signup) – om je online prijslijst te zetten | gratis |
| Een [TMDB-account](https://www.themoviedb.org/signup) – film- en seriedatabase voor de kijklijst | gratis voor testen, zie stap 9 |

---

## Stap 1 – Project klaarzetten

1. Pak `abonnement-app.zip` uit, bijvoorbeeld in `Documenten/abonnement-app`.
2. Open een terminal in die map (Windows: rechtsklik in de map → *Openen in Terminal*).
3. Voer uit:

```bash
npm install
npx expo install --fix
```

Het tweede commando zet alle onderdelen op de juiste, onderling passende versies. Krijg je een melding over een nieuwere Expo-versie: accepteren is prima.

## Stap 2 – Eigen naam in de app (optioneel, maar doe het vóór de eerste upload)

In `app.json`:
- `"name": "Abo Radar"` → de naam onder het icoontje.
- `"package": "com.matthewheyes.aboradar"` → de unieke ID in de Play Store. **Kan na de eerste upload nooit meer veranderen.**

## Stap 3 – Testversie op je eigen telefoon

```bash
npm install -g eas-cli
eas login
eas init
eas build --platform android --profile preview
```

Na 10–20 minuten krijg je een link naar een `.apk`-bestand. Open die op je Android-telefoon, installeer, en probeer alles uit:

- Abonnement toevoegen (kies Netflix uit de lijst, of "Ander abonnement"), bewerken, verwijderen.
- Bedrag van een bestaand abonnement aanpassen → de app vraagt of de prijs is veranderd en zet hem in de prijsgeschiedenis.
- Bij een abonnement "+ Aangekondigde prijswijziging toevoegen" → op het startscherm verschijnt hij onder Prijswijzigingen.
- Twee of meer streamingdiensten toevoegen → kaart "Je hebt X streamingdiensten" verschijnt.

*Tip:* zet een abonnement op morgen met herinnering "Op de dag zelf", dan zie je morgenochtend om 9:00 of de melding werkt.

**Streaming-advies testen zonder te betalen:** zet in `src/config.ts` tijdelijk `FORCE_PREMIUM_FOR_TESTING = true`. Zet hem **terug op `false`** vóór je een versie voor de Play Store bouwt.

**Let op:** de app bevat een klein stukje eigen Android-code (voor het meten van kijktijd, in de map `modules/usage-stats`). Werkt een build daardoor niet, plak de foutmelding uit de Expo-buildlog in de chat met Claude.

## Stap 4 – App aanmaken in Google Play Console

1. Ga naar [Play Console](https://play.google.com/console) → **App maken**.
2. Naam: *Abo Radar*, standaardtaal Nederlands, type *App*, *Gratis*.
3. Vul onder **App-content** in:
   - **Privacybeleid**: zet de tekst uit `PRIVACYBELEID.md` online (bijv. gratis via Google Sites of een GitHub-pagina) en plak de link. Vul eerst je naam en e-mail in.
   - **Advertenties**: Nee.
   - **Gegevensveiligheid**: "Aankoopgeschiedenis" wordt verzameld (voor app-functionaliteit, niet gedeeld, versleuteld). De kijktijd en de kijklijst blijven op de telefoon en tellen volgens Google niet als "verzameld". Zoekopdrachten in de kijklijst gaan wel naar TMDB; vul dat in als "App-activiteit → Andere door gebruikers gegenereerde content", niet gedeeld, niet gekoppeld aan de gebruiker.
   - **Gebruikstoegang**: de app vraagt toestemming om kijktijd in streaming-apps te meten. In de app staat vóór de knop al een duidelijke uitleg (dat eist Google). Noem het ook in je store-beschrijving.
   - **Doelgroep**: 18+ (dan heb je het minste gedoe).
   - **Contentclassificatie**: vragenlijst invullen, alles "nee".
4. **Store-vermelding** – zie de teksten onderaan dit document. Icoon: `assets/store-icon-512.png`. Je hebt ook minimaal 2 schermafbeeldingen nodig: maak die op je telefoon in de testversie (met een paar voorbeeldabonnementen erin), en een "feature graphic" van 1024×500 (makkelijk te maken in Canva).

## Stap 5 – Verplichte test met 12 personen (nieuwe accounts)

Google eist voor nieuwe persoonlijke ontwikkelaarsaccounts dat je app eerst **minimaal 14 dagen in een gesloten test** staat met **minimaal 12 testers**, voordat je hem openbaar mag maken. Vraag vrienden en familie met Android, of zoek testers via Reddit (r/AndroidClosedTesting) of tester-ruilgroepen.

Bouw de echte versie:

```bash
eas build --platform android --profile production
```

Je krijgt een `.aab`-bestand. Upload dat in Play Console onder **Testen → Gesloten testen**.

## Stap 6 – Premium-betaling aanzetten

Hiermee verdien je geld. Zonder deze stap werkt de app gewoon, maar alleen gratis (5 abonnementen).

1. **Play Console** → *Instellingen → Betalingsprofiel*: maak een betalingsprofiel aan (bankrekening voor uitbetalingen).
2. **Play Console** → je app → *Inkomsten genereren → Producten → In-app-producten* → **Product maken**:
   - Product-ID: `premium_unlock`
   - Naam: *Abo Radar Premium*
   - Prijs: bijvoorbeeld **€ 3,99** → *Activeren*.
   (Dit kan pas nadat er een build met betaal-ondersteuning is geüpload — die heb je in stap 5 gedaan.)
3. **RevenueCat**:
   - Maak een project → *Add app* → *Google Play* → package name uit stap 2.
   - Volg hun uitleg om een *service account* te koppelen (zo mag RevenueCat aankopen controleren).
   - *Products* → importeer `premium_unlock`.
   - *Entitlements* → maak er één met de naam **`premium`** en koppel het product.
   - *Offerings* → de standaard-offering → voeg een package toe met `premium_unlock`.
   - *API keys* → kopieer de **Google Play public key** (begint met `goog_`).
4. Open `src/config.ts` en plak de key:

```ts
export const REVENUECAT_ANDROID_KEY = 'goog_jouwkeyhier';
```

5. Bouw opnieuw (`eas build --platform android --profile production`) en upload de nieuwe `.aab` naar je test.
6. Voeg jezelf toe als *licentietester* (Play Console → Instellingen → Licentietests): dan kun je de aankoop testen zonder echt te betalen.

## Stap 7 – Live!

Na 14 dagen testen: Play Console → **Productie → Toegang aanvragen**. Na goedkeuring maak je een productie-release met dezelfde `.aab`. Google controleert de app (meestal 1–7 dagen) en daarna staat hij in de Play Store.

**Nieuwe versie uitbrengen?** Pas de code aan, `eas build --platform android --profile production`, upload. Het versienummer gaat automatisch omhoog.

## Stap 8 – Online prijslijst (prijswijzigingen automatisch doorgeven)

De app heeft een ingebouwde prijslijst (gecontroleerd september 2026). Zet je een kopie online, dan kun je **zonder app-update** nieuwe prijzen en aangekondigde prijswijzigingen naar alle gebruikers sturen. Wie dat abonnement heeft, ziet dan op het startscherm bijvoorbeeld "Netflix wordt duurder: € 15,99 → € 17,99 per 15 nov" met de knoppen *Overnemen* en *Negeren*.

1. Maak op GitHub een nieuwe, **openbare** repository, bijv. `aboradar-prijzen`.
2. Upload het bestand `prijsfeed.json` uit de projectmap.
3. Klik op het bestand → knop **Raw** → kopieer de link (begint met `https://raw.githubusercontent.com/...`).
4. Plak die link in `src/config.ts` bij `PRICE_FEED_URL` en bouw de app opnieuw.

**Een prijswijziging aankondigen** (bijv. Netflix verhoogt Standaard per 15 november naar € 17,99): open `prijsfeed.json` op GitHub, klik op het potloodje, en

- verhoog `"version"` met 1 (bijv. van `1` naar `2`), anders negeert de app het bestand;
- voeg in `"announcements"` een regel toe:

```json
"announcements": [
  { "id": "netflix-standard-2026-11", "planId": "netflix-standard", "date": "2026-11-15", "toCents": 1799, "note": "Netflix verhoogt de prijzen in Nederland." }
]
```

- `id`: iets unieks, nooit hergebruiken. `planId`: staat bij het abonnement in de lijst daarboven. `toCents`: nieuwe prijs in centen (€ 17,99 = 1799). `date`: ingangsdatum als jjjj-mm-dd.
- Na de ingangsdatum: pas ook `"cents"` bij dat plan aan naar de nieuwe prijs, zodat nieuwe gebruikers meteen de goede prijs zien.

Een nieuwe dienst toevoegen werkt hetzelfde: kopieer een bestaand blok in `"services"` en pas het aan. Klik op **Commit changes**; gebruikers krijgen het bij de volgende keer openen van de app.

**Tip:** volg nieuws over prijsverhogingen via Google Alerts op "prijsverhoging Netflix", "Disney+ duurder", enz. Snel aankondigen maakt je app waardevol.

## Stap 9 – Kijklijst aanzetten (TMDB)

De kijklijst in het streaming-advies zoekt series en films op en kijkt op welke Nederlandse diensten ze staan. Dat komt van **TMDB** (beschikbaarheidsgegevens van JustWatch).

1. Maak een account op [themoviedb.org](https://www.themoviedb.org/signup) → *Instellingen → API* → vraag een API-sleutel aan.
2. Kopieer de **API Read Access Token** (de lange code) en plak hem in `src/config.ts` bij `TMDB_READ_TOKEN`.
3. Bouw opnieuw. Zonder token verbergt de app de kijklijst; het advies werkt dan alleen op kijktijd.

**Belangrijk voordat je live gaat:** de gratis TMDB-sleutel is alleen voor niet-commercieel gebruik. Omdat Abo Radar geld verdient met Premium, moet je TMDB vragen om toestemming voor commercieel gebruik (via het e-mailadres in hun [FAQ](https://developer.themoviedb.org/docs/faq)). Leg uit dat het een kleine app is die alleen de beschikbaarheid per land toont. Alternatieven zoals Watchmode kosten honderden dollars per maand, dus TMDB is de logische keuze.

TMDB eist ook hun logo in de app. De tekstvermelding staat al onderaan het advies-scherm; zet hun officiële logo (te downloaden via hun site) ernaast voordat je live gaat.

## Hoe "welke gebruik je het meest" werkt

- **Automatisch (Android):** na toestemming leest de app hoeveel minuten je de afgelopen 30 dagen in Netflix, Prime Video, HBO Max enz. hebt gekeken, **op die telefoon**. Kijk je op de tv, dan telt dat niet mee.
- **Zelf invullen:** bij elke streamingdienst kies je *Dagelijks / Wekelijks / Maandelijks / Zelden*. De app neemt de hoogste van de twee.
- **Advies:** diensten die je dagelijks gebruikt blijven altijd. Daarnaast zoekt de app de goedkoopste combinatie waarmee je je hele kijklijst kunt zien. Staat alles van Prime Video ook op Netflix, en kijk je Prime weinig, dan krijg je "Overweeg opzeggen" met de besparing erbij.

---

## Eerlijk over verdienen

- Google houdt 15% in van elke aankoop.
- Een app in de Play Store zetten levert vanzelf nog geen downloads op. Wat helpt:
  - Goede **zoekwoorden** in titel en beschrijving ("abonnementen bijhouden", "vaste lasten", "geld besparen").
  - Vraag tevreden gebruikers om een **review**.
  - Laat het zien op TikTok/Instagram ("Ik betaalde €87 per maand aan abonnementen zonder het te weten…" werkt goed).
  - Post in r/geldzaken, r/thenetherlands, besparingsforums.
- Reken realistisch: de eerste maanden een handvol verkopen. Groei komt van reviews en zoekpositie.

**Ideeën voor later** (vraag maar, dan bouw ik ze): maandelijks overzichtsrapport, export naar Excel, widget op het startscherm, gedeelde abonnementen met huisgenoten, opzeg-links per dienst.

---

## Store-teksten (kopiëren en plakken)

**Titel (max 30 tekens):**
Abo Radar: abonnementen

**Korte beschrijving (max 80 tekens):**
Zie wat je abonnementen écht kosten en krijg een seintje vóór elke afschrijving.

**Volledige beschrijving:**

Weet jij hoeveel je elke maand kwijt bent aan abonnementen? De meeste mensen schatten het de helft te laag.

Abo Radar zet al je abonnementen overzichtelijk op een rij: streaming, muziek, sportschool, telefoon, verzekeringen, apps en meer. Je ziet direct wat je per maand én per jaar betaalt.

✓ Totaal per maand en per jaar in één oogopslag
✓ Herinnering vóór elke afschrijving, zodat je op tijd kunt opzeggen
✓ Zie meteen wanneer een abonnement duurder of goedkoper wordt, met prijsgeschiedenis
✓ Waarschuwing vóór aangekondigde prijsverhogingen van Netflix, Disney+, HBO Max, Spotify en meer
✓ Streaming-advies: welke diensten gebruik je echt, en welke kun je opzeggen omdat dezelfde series en films ook ergens anders staan?
✓ Kies je abonnement uit de lijst met actuele Nederlandse prijzen
✓ Per week, maand, kwartaal of jaar
✓ Sorteer op eerstvolgende, duurste of naam
✓ Werkt zonder account, je gegevens blijven op je telefoon
✓ Geen advertenties
✓ Donkere modus

Gratis voor maximaal 5 abonnementen. Met Premium (eenmalige aankoop, geen abonnement!) voeg je onbeperkt abonnementen toe, krijg je het streaming-advies en zie je je uitgaven per categorie.

Om je kijktijd te meten vraagt de app (optioneel) toegang tot gebruiksstatistieken. Die gegevens blijven op je telefoon.

Stop met betalen voor dingen die je niet gebruikt.

---

**English (optional second language)**

Title: Abo Radar: Subscriptions
Short: See what your subscriptions really cost and get reminded before every charge.
