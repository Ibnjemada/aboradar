import { Verdict } from './advisor';
import { Category, Cycle, Usage } from './types';

function joinNL(items: string[]): string {
  if (items.length <= 1) return items.join('');
  return `${items.slice(0, -1).join(', ')} en ${items[items.length - 1]}`;
}
function joinEN(items: string[]): string {
  if (items.length <= 1) return items.join('');
  return `${items.slice(0, -1).join(', ')} and ${items[items.length - 1]}`;
}

const nl = {
  appName: 'Abo Radar',
  perMonth: 'per maand',
  perYear: 'per jaar',
  yourSubs: 'Jouw abonnementen',
  empty: 'Nog geen abonnementen.\nTik op + om je eerste toe te voegen.',
  add: 'Toevoegen',
  edit: 'Bewerken',
  save: 'Opslaan',
  cancel: 'Annuleren',
  delete: 'Verwijderen',
  close: 'Sluiten',
  back: 'Terug',
  deleteConfirm: (name: string) => `"${name}" verwijderen?`,
  name: 'Naam',
  namePh: 'bijv. Netflix',
  amount: 'Bedrag (€)',
  amountPh: '12,99',
  cycle: 'Hoe vaak',
  firstDate: 'Datum van (eerste) afschrijving',
  datePh: 'dd-mm-jjjj',
  category: 'Categorie',
  reminder: 'Herinnering',
  noReminder: 'Uit',
  daysBefore: (n: number) => (n === 0 ? 'Op de dag zelf' : n === 1 ? '1 dag van tevoren' : `${n} dagen van tevoren`),
  errName: 'Vul een naam in.',
  errAmount: 'Vul een geldig bedrag in, bijv. 12,99.',
  errDate: 'Vul een geldige datum in als dd-mm-jjjj.',
  today: 'Vandaag',
  tomorrow: 'Morgen',
  inDays: (n: number) => `Over ${n} dagen`,
  sortNext: 'Eerstvolgend',
  sortPrice: 'Duurste',
  sortName: 'Naam',
  cycles: { week: 'Per week', month: 'Per maand', quarter: 'Per kwartaal', year: 'Per jaar' } as Record<Cycle, string>,
  cyclesShort: { week: '/wk', month: '/mnd', quarter: '/kw', year: '/jr' } as Record<Cycle, string>,
  categories: {
    streaming: 'Streaming',
    music: 'Muziek',
    software: 'Software & apps',
    sport: 'Sport & gezondheid',
    insurance: 'Verzekering',
    telecom: 'Telefoon & internet',
    news: 'Kranten & tijdschriften',
    other: 'Overig',
  } as Record<Category, string>,
  byCategory: 'Per categorie',
  premium: 'Premium',
  savingsTip: (amount: string) => `Eén abonnement opzeggen bespaart je al gauw ${amount} per jaar.`,

  // Service picker
  pickService: 'Kies een dienst',
  searchService: 'Zoek een dienst…',
  customSub: 'Ander abonnement',
  customSubHint: 'Sportschool, verzekering, krant, …',
  fromPrice: (p: string) => `vanaf ${p}`,
  plan: 'Abonnementsvorm',
  catalogPrice: (plan: string, price: string) => `Volgens onze prijslijst kost ${plan} nu ${price}.`,
  useCatalogPrice: 'Gebruiken',

  // Price changes
  priceChanges: 'Prijswijzigingen',
  becomesMoreExpensive: (name: string) => `${name} wordt duurder`,
  becomesCheaper: (name: string) => `${name} wordt goedkoper`,
  wentUp: (name: string) => `${name} is duurder geworden`,
  wentDown: (name: string) => `${name} is goedkoper geworden`,
  fromToPer: (from: string, to: string, date: string) => `${from} → ${to} per ${date}`,
  fromToSince: (from: string, to: string, date: string) => `${from} → ${to} sinds ${date}`,
  announcedLabel: 'Aangekondigd',
  plannedLabel: 'Gepland',
  accept: 'Overnemen',
  ignore: 'Negeren',
  rowScheduled: (to: string, date: string) => `${to} per ${date}`,
  rowRecent: (delta: string, date: string) => `${delta} sinds ${date}`,
  heroDelta: (delta: string) => `${delta} p/m door aangekondigde prijswijzigingen`,
  futureChange: 'Prijswijziging',
  addFutureChange: '+ Aangekondigde prijswijziging toevoegen',
  newPrice: 'Nieuwe prijs (€)',
  effectiveDate: 'Ingangsdatum',
  errNewPrice: 'Vul een geldige nieuwe prijs in die anders is dan de huidige.',
  errEffectiveDate: 'Vul een geldige ingangsdatum in als dd-mm-jjjj.',
  history: 'Prijsgeschiedenis',
  priceChangedQ: 'Is de prijs veranderd?',
  priceChangedBody: (from: string, to: string) => `Van ${from} naar ${to}. Bij een prijswijziging bewaren we de oude prijs in de geschiedenis.`,
  yesChanged: 'Ja, prijs gewijzigd',
  noTypo: 'Nee, typfout verbeterd',
  notifPriceUp: (name: string) => `${name} wordt duurder`,
  notifPriceDown: (name: string) => `${name} wordt goedkoper`,
  notifPriceBody: (from: string, to: string, date: string) => `Van ${from} naar ${to} per ${date}. Nog de moeite waard?`,

  // Reminders
  notifTitle: (name: string) => `${name} wordt binnenkort afgeschreven`,
  notifBody: (amount: string, when: string) => `${amount} — ${when}. Nog nodig? Opzeggen kan nu nog.`,
  notifChannel: 'Herinneringen',

  // Streaming advisor
  usageQ: 'Hoe vaak kijk je?',
  usages: { daily: 'Dagelijks', weekly: 'Wekelijks', monthly: 'Maandelijks', rarely: 'Zelden' } as Record<Usage, string>,
  advisorTitle: 'Streaming-advies',
  teaserTitle: (n: number) => `Je hebt ${n} streamingdiensten`,
  teaserBody: (total: string) => `Samen ${total} per maand. Welke kun je missen?`,
  youPay: (total: string, n: number) => `Je betaalt ${total} per maand aan ${n} streamingdiensten.`,
  adviceKeep: (names: string[]) => (names.length ? `Advies: houd ${joinNL(names)}.` : 'Advies: je kunt ze allemaal missen.'),
  adviceSavings: (month: string, year: string) =>
    `Dan kun je alles van je kijklijst zien en bespaar je ${month} per maand (${year} per jaar).`,
  adviceAllNeeded: 'Je hebt al deze diensten nodig om je hele kijklijst te zien.',
  adviceAddWatchlist: 'Voeg onderaan series en films toe die je wilt kijken. Dan zien we welke diensten dezelfde titels hebben.',
  adviceNotCovered: (n: number) => `${n} ${n === 1 ? 'titel' : 'titels'} van je kijklijst ${n === 1 ? 'staat' : 'staan'} op geen van je diensten.`,
  verdicts: { keep: 'Houden', consider: 'Overweeg opzeggen', unsure: 'Twijfel' } as Record<Verdict, string>,
  duration: (minutes: number) => (minutes < 60 ? `${minutes} min` : `${Math.round(minutes / 60)} uur`),
  reasonMeasured: (d: string) => `Op deze telefoon ${d} gekeken in 30 dagen`,
  reasonLevel: ['Je kijkt er zelden naar', 'Je kijkt er maandelijks naar', 'Je kijkt er wekelijks naar', 'Je kijkt er dagelijks naar'],
  reasonUnique: (n: number, examples: string[]) =>
    `${n} van je kijklijst ${n === 1 ? 'staat' : 'staan'} alleen hier: ${joinNL(examples)}${n > examples.length ? ', …' : ''}`,
  reasonElsewhere: (n: number, names: string[]) =>
    `${n === 1 ? 'Je titel' : `Al je ${n} titels`} hier ${n === 1 ? 'staat' : 'staan'} ook op ${joinNL(names)}`,
  reasonNothing: 'Niets van je kijklijst staat hierop',
  reasonDuplicate: 'Je hebt deze dienst dubbel staan',
  reasonNoInfo: 'Geef aan hoe vaak je kijkt voor een advies',
  autoTitle: 'Kijktijd automatisch meten',
  autoBody:
    'Abo Radar kan op deze telefoon zien hoeveel minuten je de afgelopen 30 dagen in je streaming-apps hebt gekeken. We kijken alleen naar die apps en de gegevens blijven op je telefoon. Kijk je vooral op tv? Vul dan zelf in hoe vaak je kijkt.',
  autoButton: 'Toestemming geven',
  autoHint: 'Kies "Abo Radar" in de lijst en zet "Gebruikstoegang toestaan" aan. Kom daarna terug naar de app.',
  autoOn: 'Kijktijd wordt gemeten op deze telefoon (laatste 30 dagen).',
  watchlistTitle: 'Mijn kijklijst',
  watchlistBody: 'Voeg series en films toe die je wilt kijken. We zoeken op welke diensten ze in Nederland staan.',
  searchTitles: 'Zoek een serie of film…',
  notStreaming: 'Nu niet in een abonnement te zien',
  searchFailed: 'Zoeken lukt nu niet. Controleer je internetverbinding.',
  noResults: 'Niets gevonden.',
  added: 'Toegevoegd',
  rotationTip:
    'Tip: de meeste streamingdiensten zeg je per maand op. Kijk een serie af, zeg op, en neem daarna een andere. Zo betaal je maar voor één dienst tegelijk.',
  attribution:
    'Film- en seriegegevens: TMDB. Beschikbaarheid: JustWatch. This product uses the TMDB API but is not endorsed or certified by TMDB.',
  tmdbLanguage: 'nl-NL',

  // Premium
  premiumTitle: 'Abo Radar Premium',
  premiumSub: 'Eenmalig betalen, voor altijd gebruiken.',
  premiumFeatures: [
    'Onbeperkt abonnementen (gratis: 5)',
    'Streaming-advies: welke diensten kun je missen?',
    'Overzicht per categorie',
    'Steun een onafhankelijke maker',
  ],
  buy: (price: string) => `Ontgrendel voor ${price}`,
  restore: 'Aankoop herstellen',
  premiumActive: 'Premium is actief. Bedankt!',
  limitReached: 'Je hebt het maximum van 5 gratis abonnementen bereikt.',
  advisorLocked: 'Streaming-advies is onderdeel van Premium.',
  purchaseFailed: 'De aankoop is niet gelukt. Probeer het later opnieuw.',
  purchaseUnavailable: 'Aankopen zijn op dit moment niet beschikbaar.',
  restoredNone: 'Geen eerdere aankoop gevonden.',
};

type Strings = typeof nl;

const en: Strings = {
  appName: 'Abo Radar',
  perMonth: 'per month',
  perYear: 'per year',
  yourSubs: 'Your subscriptions',
  empty: 'No subscriptions yet.\nTap + to add your first one.',
  add: 'Add',
  edit: 'Edit',
  save: 'Save',
  cancel: 'Cancel',
  delete: 'Delete',
  close: 'Close',
  back: 'Back',
  deleteConfirm: (name: string) => `Delete "${name}"?`,
  name: 'Name',
  namePh: 'e.g. Netflix',
  amount: 'Amount (€)',
  amountPh: '12.99',
  cycle: 'Billing cycle',
  firstDate: 'Date of (first) charge',
  datePh: 'dd-mm-yyyy',
  category: 'Category',
  reminder: 'Reminder',
  noReminder: 'Off',
  daysBefore: (n: number) => (n === 0 ? 'On the day' : n === 1 ? '1 day before' : `${n} days before`),
  errName: 'Please enter a name.',
  errAmount: 'Please enter a valid amount, e.g. 12.99.',
  errDate: 'Please enter a valid date as dd-mm-yyyy.',
  today: 'Today',
  tomorrow: 'Tomorrow',
  inDays: (n: number) => `In ${n} days`,
  sortNext: 'Next up',
  sortPrice: 'Priciest',
  sortName: 'Name',
  cycles: { week: 'Weekly', month: 'Monthly', quarter: 'Quarterly', year: 'Yearly' },
  cyclesShort: { week: '/wk', month: '/mo', quarter: '/qtr', year: '/yr' },
  categories: {
    streaming: 'Streaming',
    music: 'Music',
    software: 'Software & apps',
    sport: 'Fitness & health',
    insurance: 'Insurance',
    telecom: 'Phone & internet',
    news: 'News & magazines',
    other: 'Other',
  },
  byCategory: 'By category',
  premium: 'Premium',
  savingsTip: (amount: string) => `Cancelling one subscription can easily save you ${amount} a year.`,

  pickService: 'Choose a service',
  searchService: 'Search a service…',
  customSub: 'Other subscription',
  customSubHint: 'Gym, insurance, newspaper, …',
  fromPrice: (p: string) => `from ${p}`,
  plan: 'Plan',
  catalogPrice: (plan: string, price: string) => `According to our price list, ${plan} now costs ${price}.`,
  useCatalogPrice: 'Use',

  priceChanges: 'Price changes',
  becomesMoreExpensive: (name: string) => `${name} is getting more expensive`,
  becomesCheaper: (name: string) => `${name} is getting cheaper`,
  wentUp: (name: string) => `${name} went up`,
  wentDown: (name: string) => `${name} went down`,
  fromToPer: (from: string, to: string, date: string) => `${from} → ${to} from ${date}`,
  fromToSince: (from: string, to: string, date: string) => `${from} → ${to} since ${date}`,
  announcedLabel: 'Announced',
  plannedLabel: 'Scheduled',
  accept: 'Apply',
  ignore: 'Ignore',
  rowScheduled: (to: string, date: string) => `${to} from ${date}`,
  rowRecent: (delta: string, date: string) => `${delta} since ${date}`,
  heroDelta: (delta: string) => `${delta}/mo from announced price changes`,
  futureChange: 'Price change',
  addFutureChange: '+ Add an announced price change',
  newPrice: 'New price (€)',
  effectiveDate: 'Effective date',
  errNewPrice: 'Please enter a valid new price that differs from the current one.',
  errEffectiveDate: 'Please enter a valid effective date as dd-mm-yyyy.',
  history: 'Price history',
  priceChangedQ: 'Did the price change?',
  priceChangedBody: (from: string, to: string) => `From ${from} to ${to}. For a price change we keep the old price in the history.`,
  yesChanged: 'Yes, price changed',
  noTypo: 'No, fixed a typo',
  notifPriceUp: (name: string) => `${name} is getting more expensive`,
  notifPriceDown: (name: string) => `${name} is getting cheaper`,
  notifPriceBody: (from: string, to: string, date: string) => `From ${from} to ${to} on ${date}. Still worth it?`,

  notifTitle: (name: string) => `${name} renews soon`,
  notifBody: (amount: string, when: string) => `${amount} — ${when}. Still using it? You can cancel now.`,
  notifChannel: 'Reminders',

  usageQ: 'How often do you watch?',
  usages: { daily: 'Daily', weekly: 'Weekly', monthly: 'Monthly', rarely: 'Rarely' },
  advisorTitle: 'Streaming advice',
  teaserTitle: (n: number) => `You have ${n} streaming services`,
  teaserBody: (total: string) => `${total} a month together. Which can you do without?`,
  youPay: (total: string, n: number) => `You pay ${total} a month for ${n} streaming services.`,
  adviceKeep: (names: string[]) => (names.length ? `Advice: keep ${joinEN(names)}.` : 'Advice: you can do without all of them.'),
  adviceSavings: (month: string, year: string) =>
    `You can still watch your whole watchlist and save ${month} a month (${year} a year).`,
  adviceAllNeeded: 'You need all of these services to watch your whole watchlist.',
  adviceAddWatchlist: 'Add series and films you want to watch below, and we will show which services carry the same titles.',
  adviceNotCovered: (n: number) => `${n} ${n === 1 ? 'title' : 'titles'} on your watchlist ${n === 1 ? 'is' : 'are'} not on any of your services.`,
  verdicts: { keep: 'Keep', consider: 'Consider cancelling', unsure: 'Unsure' },
  duration: (minutes: number) => (minutes < 60 ? `${minutes} min` : `${Math.round(minutes / 60)} h`),
  reasonMeasured: (d: string) => `${d} watched on this phone in 30 days`,
  reasonLevel: ['You rarely watch it', 'You watch it monthly', 'You watch it weekly', 'You watch it daily'],
  reasonUnique: (n: number, examples: string[]) =>
    `${n} on your watchlist ${n === 1 ? 'is' : 'are'} only here: ${joinEN(examples)}${n > examples.length ? ', …' : ''}`,
  reasonElsewhere: (n: number, names: string[]) =>
    `${n === 1 ? 'Your title' : `All ${n} of your titles`} here ${n === 1 ? 'is' : 'are'} also on ${joinEN(names)}`,
  reasonNothing: 'Nothing on your watchlist is on here',
  reasonDuplicate: 'You have this service twice',
  reasonNoInfo: 'Tell us how often you watch to get advice',
  autoTitle: 'Measure watch time automatically',
  autoBody:
    'Abo Radar can see how many minutes you spent in your streaming apps on this phone over the last 30 days. We only look at those apps and the data stays on your phone. Mostly watch on TV? Then set how often you watch yourself.',
  autoButton: 'Grant access',
  autoHint: 'Choose "Abo Radar" in the list and turn on "Permit usage access". Then come back to the app.',
  autoOn: 'Watch time is measured on this phone (last 30 days).',
  watchlistTitle: 'My watchlist',
  watchlistBody: 'Add series and films you want to watch. We look up which services carry them in the Netherlands.',
  searchTitles: 'Search a series or film…',
  notStreaming: 'Not included in any subscription right now',
  searchFailed: 'Search is not working right now. Check your internet connection.',
  noResults: 'Nothing found.',
  added: 'Added',
  rotationTip:
    'Tip: most streaming services can be cancelled monthly. Finish a series, cancel, then pick another. That way you only pay for one at a time.',
  attribution:
    'Film and series data: TMDB. Availability: JustWatch. This product uses the TMDB API but is not endorsed or certified by TMDB.',
  tmdbLanguage: 'en-US',

  premiumTitle: 'Abo Radar Premium',
  premiumSub: 'Pay once, use forever.',
  premiumFeatures: [
    'Unlimited subscriptions (free: 5)',
    'Streaming advice: which services can you drop?',
    'Breakdown by category',
    'Support an independent maker',
  ],
  buy: (price: string) => `Unlock for ${price}`,
  restore: 'Restore purchase',
  premiumActive: 'Premium is active. Thank you!',
  limitReached: "You've reached the limit of 5 free subscriptions.",
  advisorLocked: 'Streaming advice is part of Premium.',
  purchaseFailed: 'The purchase did not go through. Please try again later.',
  purchaseUnavailable: 'Purchases are not available right now.',
  restoredNone: 'No previous purchase found.',
};

function deviceLocale(): string {
  try {
    return Intl.DateTimeFormat().resolvedOptions().locale || 'nl-NL';
  } catch {
    return 'nl-NL';
  }
}

export const locale = deviceLocale();
const isNL = locale.toLowerCase().startsWith('nl');
export const t: Strings = isNL ? nl : en;

const moneyFmt = new Intl.NumberFormat(isNL ? 'nl-NL' : locale, { style: 'currency', currency: 'EUR' });

export function money(cents: number): string {
  return moneyFmt.format(cents / 100);
}

/** "+€ 2,00" / "−€ 1,00" */
export function moneyDelta(cents: number): string {
  if (cents === 0) return money(0);
  return `${cents > 0 ? '+' : '−'}${money(Math.abs(cents))}`;
}

export function relativeDay(days: number): string {
  if (days <= 0) return t.today;
  if (days === 1) return t.tomorrow;
  return t.inDays(days);
}

export function shortDate(date: Date): string {
  try {
    return date.toLocaleDateString(locale, { day: 'numeric', month: 'short' });
  } catch {
    return `${date.getDate()}-${date.getMonth() + 1}`;
  }
}

export function longDate(date: Date): string {
  try {
    return date.toLocaleDateString(locale, { day: 'numeric', month: 'short', year: 'numeric' });
  } catch {
    return `${date.getDate()}-${date.getMonth() + 1}-${date.getFullYear()}`;
  }
}

export function joinNames(names: string[]): string {
  return isNL ? joinNL(names) : joinEN(names);
}
