import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { addCycles, amountOn, daysUntil, nextCharge, parseISO, startOfToday } from './calc';
import { money, relativeDay, shortDate, t } from './i18n';
import { Subscription } from './types';

const CHANNEL_ID = 'reminders';
const REMIND_HOUR = 9;
/** Days before a price change takes effect that we warn the user. */
const PRICE_WARN_DAYS = 7;
/** Android allows ~500 scheduled alarms; we keep it well below that. */
const MAX_SCHEDULED = 60;

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: false,
    shouldSetBadge: false,
  }),
});

async function ensureChannel(): Promise<void> {
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync(CHANNEL_ID, {
      name: t.notifChannel,
      importance: Notifications.AndroidImportance.DEFAULT,
    });
  }
}

export async function setupNotifications(): Promise<boolean> {
  await ensureChannel();
  const current = await Notifications.getPermissionsAsync();
  if (current.granted) return true;
  if (!current.canAskAgain) return false;
  const req = await Notifications.requestPermissionsAsync();
  return req.granted;
}

interface Planned {
  when: Date;
  title: string;
  body: string;
  subscriptionId: string;
}

/**
 * Cancel everything and schedule the upcoming reminders: the next two charges
 * per subscription, plus a warning before each scheduled price change.
 * Called after every change and on app start, so it always matches the data.
 */
export async function rescheduleAll(subs: Subscription[]): Promise<void> {
  try {
    await ensureChannel();
    await Notifications.cancelAllScheduledNotificationsAsync();
    const now = new Date();
    const today = startOfToday();
    const items: Planned[] = [];

    for (const sub of subs) {
      // Charge reminders
      if (sub.remindDaysBefore >= 0) {
        const first = nextCharge(sub, today);
        const start = parseISO(sub.startDate);
        let n = 0;
        while (addCycles(start, sub.cycle, n) < first) n++;
        for (let k = 0; k < 2; k++) {
          const charge = addCycles(start, sub.cycle, n + k);
          const when = new Date(charge.getFullYear(), charge.getMonth(), charge.getDate() - sub.remindDaysBefore, REMIND_HOUR);
          if (when <= now) continue;
          const reminderDay = new Date(when.getFullYear(), when.getMonth(), when.getDate());
          items.push({
            when,
            subscriptionId: sub.id,
            title: t.notifTitle(sub.name),
            body: t.notifBody(money(amountOn(sub, charge)), relativeDay(daysUntil(charge, reminderDay)).toLowerCase()),
          });
        }
      }

      // Price change warning
      const sc = sub.scheduledChange;
      if (sc) {
        const effective = parseISO(sc.date);
        let when = new Date(effective.getFullYear(), effective.getMonth(), effective.getDate() - PRICE_WARN_DAYS, REMIND_HOUR);
        if (when <= now) {
          // Less than a week to go: warn tomorrow morning, if that is still before the change.
          when = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1, REMIND_HOUR);
        }
        if (when > now && when < effective) {
          const up = sc.toCents > sub.amountCents;
          items.push({
            when,
            subscriptionId: sub.id,
            title: up ? t.notifPriceUp(sub.name) : t.notifPriceDown(sub.name),
            body: t.notifPriceBody(money(sub.amountCents), money(sc.toCents), shortDate(effective)),
          });
        }
      }
    }

    items.sort((a, b) => a.when.getTime() - b.when.getTime());
    for (const item of items.slice(0, MAX_SCHEDULED)) {
      await Notifications.scheduleNotificationAsync({
        content: { title: item.title, body: item.body, data: { subscriptionId: item.subscriptionId } },
        trigger: {
          type: Notifications.SchedulableTriggerInputTypes.DATE,
          date: item.when,
          channelId: CHANNEL_ID,
        },
      });
    }
  } catch (e) {
    // Reminders are a convenience; never let them break the app.
    console.warn('Could not schedule reminders', e);
  }
}
