/**
 * Keys and addresses that you fill in yourself. See HANDLEIDING.md.
 * Everything works without them; the related feature then simply stays off.
 */

/** RevenueCat public Android SDK key (starts with 'goog_'). Enables Premium purchases. Step 6. */
export const REVENUECAT_ANDROID_KEY = '';

/**
 * Web address of your online price list (prijsfeed.json), e.g. a GitHub "raw" link.
 * When you update that file, every user sees new prices and announced price changes
 * without needing an app update. Step 8.
 */
export const PRICE_FEED_URL = '';

/**
 * TMDB "API Read Access Token" (the long one). Enables the watchlist in the
 * streaming advisor: which films/series are on which service. Step 9.
 */
export const TMDB_READ_TOKEN = '';

/**
 * Set to true to try all Premium features on your own phone without paying.
 * ALWAYS set back to false before building a version for the Play Store.
 */
export const FORCE_PREMIUM_FOR_TESTING = false;

/** Country used for streaming availability. */
export const WATCH_REGION = 'NL';
