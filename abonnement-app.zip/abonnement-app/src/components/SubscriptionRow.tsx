import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { daysUntil, nextCharge, parseISO, recentChange } from '../calc';
import { money, moneyDelta, relativeDay, shortDate, t } from '../i18n';
import { useTheme } from '../theme';
import { CATEGORY_COLORS, CATEGORY_ICONS, Subscription } from '../types';

interface Props {
  sub: Subscription;
  onPress: () => void;
}

export function SubscriptionRow({ sub, onPress }: Props) {
  const c = useTheme();
  const next = nextCharge(sub);
  const days = daysUntil(next);
  const soon = days <= 3;

  const sc = sub.scheduledChange;
  const recent = sc ? null : recentChange(sub, 90);
  let changeLine: { text: string; up: boolean } | null = null;
  if (sc) {
    changeLine = {
      up: sc.toCents > sub.amountCents,
      text: t.rowScheduled(money(sc.toCents), shortDate(parseISO(sc.date))),
    };
  } else if (recent) {
    changeLine = {
      up: recent.toCents > recent.fromCents,
      text: t.rowRecent(moneyDelta(recent.toCents - recent.fromCents), shortDate(parseISO(recent.date))),
    };
  }

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.row,
        { backgroundColor: c.card, borderColor: c.border, opacity: pressed ? 0.7 : 1 },
      ]}
      accessibilityRole="button"
      accessibilityLabel={`${sub.name}, ${money(sub.amountCents)} ${t.cycles[sub.cycle]}${changeLine ? `, ${changeLine.text}` : ''}`}
    >
      <View style={[styles.icon, { backgroundColor: CATEGORY_COLORS[sub.category] + '22' }]}>
        <Text style={styles.iconText}>{CATEGORY_ICONS[sub.category]}</Text>
      </View>
      <View style={styles.middle}>
        <Text style={[styles.name, { color: c.text }]} numberOfLines={1}>
          {sub.name}
        </Text>
        <View style={styles.metaRow}>
          <Text
            style={[
              styles.meta,
              soon && { color: c.warn, backgroundColor: c.warnBg, fontWeight: '600' },
              soon && styles.badge,
              !soon && { color: c.muted },
            ]}
          >
            {relativeDay(days)}
          </Text>
          <Text style={[styles.meta, { color: c.muted }]}> · {shortDate(next)}</Text>
        </View>
        {changeLine && (
          <Text style={[styles.change, { color: changeLine.up ? c.danger : c.good }]} numberOfLines={1}>
            {changeLine.up ? '↑' : '↓'} {changeLine.text}
          </Text>
        )}
      </View>
      <View style={styles.right}>
        <Text style={[styles.amount, { color: c.text }]}>{money(sub.amountCents)}</Text>
        <Text style={[styles.cycle, { color: c.muted }]}>{t.cyclesShort[sub.cycle]}</Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 14,
    borderRadius: 16,
    borderWidth: 1,
    marginBottom: 10,
  },
  icon: { width: 44, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  iconText: { fontSize: 22 },
  middle: { flex: 1, marginHorizontal: 12 },
  name: { fontSize: 16, fontWeight: '600' },
  metaRow: { flexDirection: 'row', alignItems: 'center', marginTop: 3 },
  meta: { fontSize: 13 },
  badge: { paddingHorizontal: 6, paddingVertical: 1, borderRadius: 6, overflow: 'hidden' },
  change: { fontSize: 13, fontWeight: '600', marginTop: 3 },
  right: { alignItems: 'flex-end' },
  amount: { fontSize: 16, fontWeight: '700', fontVariant: ['tabular-nums'] },
  cycle: { fontSize: 12, marginTop: 2 },
});
