import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { daysUntil, parseISO } from '../calc';
import { PendingAnnouncement } from '../catalog';
import { longDate, money, t } from '../i18n';
import { useTheme } from '../theme';
import { Subscription } from '../types';

interface Props {
  subs: Subscription[];
  pending: PendingAnnouncement[];
  onAccept: (p: PendingAnnouncement) => void;
  onIgnore: (p: PendingAnnouncement) => void;
  onOpen: (sub: Subscription) => void;
}

/** "Price changes" section on the home screen: announced, scheduled and recent changes. */
export function ChangesCard({ subs, pending, onAccept, onIgnore, onOpen }: Props) {
  const c = useTheme();

  const scheduled = subs
    .filter((s) => s.scheduledChange)
    .sort((a, b) => a.scheduledChange!.date.localeCompare(b.scheduledChange!.date));

  const recent = subs
    .filter((s) => !s.scheduledChange && s.priceHistory?.length)
    .map((s) => ({ sub: s, change: s.priceHistory![s.priceHistory!.length - 1] }))
    .filter(({ change }) => daysUntil(parseISO(change.date)) >= -30)
    .sort((a, b) => b.change.date.localeCompare(a.change.date));

  if (pending.length === 0 && scheduled.length === 0 && recent.length === 0) return null;

  const arrow = (up: boolean) => (
    <View style={[styles.arrow, { backgroundColor: up ? c.dangerBg : c.goodBg }]}>
      <Text style={[styles.arrowText, { color: up ? c.danger : c.good }]}>{up ? '↑' : '↓'}</Text>
    </View>
  );

  return (
    <View style={[styles.card, { backgroundColor: c.card, borderColor: c.border }]}>
      <Text style={[styles.title, { color: c.text }]}>{t.priceChanges}</Text>

      {pending.map((p) => {
        const up = p.announcement.toCents > p.fromCents;
        return (
          <View key={`${p.sub.id}-${p.announcement.id}`} style={[styles.item, { borderTopColor: c.border }]}>
            {arrow(up)}
            <View style={styles.itemBody}>
              <Text style={[styles.label, { color: c.warn }]}>{t.announcedLabel}</Text>
              <Text style={[styles.itemTitle, { color: c.text }]}>
                {up ? t.becomesMoreExpensive(p.sub.name) : t.becomesCheaper(p.sub.name)}
              </Text>
              <Text style={[styles.itemSub, { color: c.muted }]}>
                {t.fromToPer(money(p.fromCents), money(p.announcement.toCents), longDate(parseISO(p.announcement.date)))}
              </Text>
              {p.announcement.note ? (
                <Text style={[styles.itemSub, { color: c.muted }]}>{p.announcement.note}</Text>
              ) : null}
              <View style={styles.actions}>
                <Pressable onPress={() => onAccept(p)} style={[styles.btn, { backgroundColor: c.primary }]}>
                  <Text style={[styles.btnText, { color: c.primaryText }]}>{t.accept}</Text>
                </Pressable>
                <Pressable onPress={() => onIgnore(p)} style={[styles.btn, { borderColor: c.border, borderWidth: 1 }]}>
                  <Text style={[styles.btnText, { color: c.muted }]}>{t.ignore}</Text>
                </Pressable>
              </View>
            </View>
          </View>
        );
      })}

      {scheduled.map((s) => {
        const sc = s.scheduledChange!;
        const up = sc.toCents > s.amountCents;
        return (
          <Pressable key={`sc-${s.id}`} onPress={() => onOpen(s)} style={[styles.item, { borderTopColor: c.border }]}>
            {arrow(up)}
            <View style={styles.itemBody}>
              <Text style={[styles.label, { color: c.muted }]}>{t.plannedLabel}</Text>
              <Text style={[styles.itemTitle, { color: c.text }]}>
                {up ? t.becomesMoreExpensive(s.name) : t.becomesCheaper(s.name)}
              </Text>
              <Text style={[styles.itemSub, { color: c.muted }]}>
                {t.fromToPer(money(s.amountCents), money(sc.toCents), longDate(parseISO(sc.date)))}
              </Text>
            </View>
          </Pressable>
        );
      })}

      {recent.map(({ sub, change }) => {
        const up = change.toCents > change.fromCents;
        return (
          <Pressable key={`rc-${sub.id}`} onPress={() => onOpen(sub)} style={[styles.item, { borderTopColor: c.border }]}>
            {arrow(up)}
            <View style={styles.itemBody}>
              <Text style={[styles.itemTitle, { color: c.text }]}>{up ? t.wentUp(sub.name) : t.wentDown(sub.name)}</Text>
              <Text style={[styles.itemSub, { color: c.muted }]}>
                {t.fromToSince(money(change.fromCents), money(change.toCents), longDate(parseISO(change.date)))}
              </Text>
            </View>
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  card: { borderWidth: 1, borderRadius: 16, paddingHorizontal: 14, paddingTop: 14, paddingBottom: 4, marginBottom: 20 },
  title: { fontSize: 17, fontWeight: '700', marginBottom: 6 },
  item: { flexDirection: 'row', paddingVertical: 12, borderTopWidth: StyleSheet.hairlineWidth },
  arrow: { width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  arrowText: { fontSize: 17, fontWeight: '800' },
  itemBody: { flex: 1 },
  label: { fontSize: 11, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.6, marginBottom: 2 },
  itemTitle: { fontSize: 15, fontWeight: '600' },
  itemSub: { fontSize: 13, marginTop: 2 },
  actions: { flexDirection: 'row', marginTop: 10 },
  btn: { borderRadius: 10, paddingHorizontal: 14, paddingVertical: 8, marginRight: 8 },
  btnText: { fontSize: 14, fontWeight: '600' },
});
