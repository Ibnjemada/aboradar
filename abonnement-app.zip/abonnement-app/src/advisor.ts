/**
 * Streaming advisor: which film/series services to keep, based on
 *  - how much the user uses them (measured on the phone and/or self-reported), and
 *  - which titles on the user's watchlist are available where (overlap between services).
 * Pure logic, no device APIs.
 */
import { monthlyCents } from './calc';
import { findService, PriceFeed, resolveServiceId } from './catalog';
import { Subscription, Usage } from './types';

export interface WatchItem {
  /** "movie:123" or "tv:456" */
  key: string;
  tmdbId: number;
  type: 'movie' | 'tv';
  title: string;
  year?: string;
  poster?: string | null;
  /** Catalog service ids where this title can be streamed (flat-rate) in NL. */
  providers: string[];
  checkedAt: number;
}

export type Verdict = 'keep' | 'consider' | 'unsure';

export type Reason =
  | { code: 'usage'; level: number; minutes: number | null }
  | { code: 'unique'; n: number; examples: string[] }
  | { code: 'allElsewhere'; n: number; elsewhere: string[] }
  | { code: 'nothingOnList' }
  | { code: 'duplicate' }
  | { code: 'noInfo' };

export interface ServiceAdvice {
  sub: Subscription;
  serviceId?: string;
  monthlyCents: number;
  /** Android packages we can measure; empty if unknown. */
  packages: string[];
  /** Minutes in the last 30 days on this phone, or null if not measured. */
  autoMinutes: number | null;
  /** 0 (rarely) … 3 (daily), or null if unknown. */
  usage: number | null;
  covered: number;
  unique: number;
  uniqueTitles: string[];
  verdict: Verdict;
  reasons: Reason[];
}

export interface AdvisorResult {
  services: ServiceAdvice[];
  totalCents: number;
  /** Cheapest set of subscriptions that still covers the watchlist (null = not enough info). */
  keepIds: string[] | null;
  keepCents: number;
  savingsCents: number;
  /** Watchlist titles available on at least one of the user's services. */
  coverable: number;
  /** Watchlist titles not available on any of the user's services. */
  notCovered: number;
}

type Work = ServiceAdvice & { _duplicate: boolean; _covered: WatchItem[] };

export const USAGE_LEVEL: Record<Usage, number> = { daily: 3, weekly: 2, monthly: 1, rarely: 0 };

/** Minutes watched in 30 days on the phone → usage level. */
export function minutesToLevel(minutes: number): number {
  if (minutes >= 600) return 3; // ~20 min a day
  if (minutes >= 120) return 2; // ~30 min a week
  if (minutes >= 20) return 1;
  return 0;
}

export function isStreamingSub(sub: Subscription, feed: PriceFeed): boolean {
  const service = findService(feed, resolveServiceId(sub, feed));
  if (service) return service.streaming;
  return sub.category === 'streaming';
}

export function buildAdvice(
  subs: Subscription[],
  feed: PriceFeed,
  watchlist: WatchItem[],
  autoMinutes: Record<string, number> | null,
): AdvisorResult {
  const streaming = subs.filter((s) => isStreamingSub(s, feed));
  const resolved = streaming.map((sub) => ({ sub, serviceId: resolveServiceId(sub, feed) }));
  const ownedIds = new Set(resolved.map((r) => r.serviceId).filter((x): x is string => Boolean(x)));
  const nameOf = (id: string) => findService(feed, id)?.name ?? id;

  const titles = watchlist.filter((w) => w.providers.length > 0);
  const coverableTitles = titles.filter((w) => w.providers.some((p) => ownedIds.has(p)));
  const seen = new Set<string>();

  const services: Work[] = resolved.map(({ sub, serviceId }): Work => {
    const service = findService(feed, serviceId);
    const packages = service?.androidPackages ?? [];

    let auto: number | null = null;
    if (autoMinutes && packages.length > 0) {
      auto = Math.round(packages.reduce((acc, p) => acc + (autoMinutes[p] ?? 0), 0));
    }
    const levels: number[] = [];
    if (auto !== null) levels.push(minutesToLevel(auto));
    if (sub.usage) levels.push(USAGE_LEVEL[sub.usage]);
    const usage = levels.length ? Math.max(...levels) : null;

    const coveredTitles = serviceId ? coverableTitles.filter((w) => w.providers.includes(serviceId)) : [];
    const uniqueTitles = coveredTitles.filter((w) => w.providers.filter((p) => ownedIds.has(p)).length === 1);

    const duplicate = Boolean(serviceId && seen.has(serviceId));
    if (serviceId) seen.add(serviceId);

    return {
      sub,
      serviceId,
      monthlyCents: Math.round(monthlyCents(sub)),
      packages,
      autoMinutes: auto,
      usage,
      covered: coveredTitles.length,
      unique: duplicate ? 0 : uniqueTitles.length,
      uniqueTitles: duplicate ? [] : uniqueTitles.map((w) => w.title),
      verdict: 'unsure',
      reasons: [],
      _duplicate: duplicate,
      _covered: coveredTitles,
    };
  });

  const totalCents = services.reduce((acc, s) => acc + s.monthlyCents, 0);

  // Cheapest combination that keeps every coverable title watchable and keeps daily-used services.
  let keepIds: string[] | null = null;
  let keepCents = 0;
  const candidates = services.filter((s) => !s._duplicate);
  if (coverableTitles.length > 0 && candidates.length <= 14) {
    let best: { mask: number; cost: number; count: number } | null = null;
    const n = candidates.length;
    for (let mask = 0; mask < 1 << n; mask++) {
      const chosen = candidates.filter((_, i) => mask & (1 << i));
      if (candidates.some((c, i) => c.usage === 3 && !(mask & (1 << i)))) continue;
      const ids = new Set(chosen.map((c) => c.serviceId));
      if (!coverableTitles.every((w) => w.providers.some((p) => ids.has(p)))) continue;
      const cost = chosen.reduce((acc, c) => acc + c.monthlyCents, 0);
      if (!best || cost < best.cost || (cost === best.cost && chosen.length < best.count)) {
        best = { mask, cost, count: chosen.length };
      }
    }
    if (best) {
      keepIds = candidates.filter((_, i) => best!.mask & (1 << i)).map((c) => c.sub.id);
      keepCents = best.cost;
    }
  }

  for (const s of services) {
    const reasons: Reason[] = [];
    if (s.usage !== null) reasons.push({ code: 'usage', level: s.usage, minutes: s.autoMinutes });

    if (s._duplicate) {
      s.verdict = 'consider';
      s.reasons = [{ code: 'duplicate' }];
      continue;
    }

    if (keepIds) {
      if (s.unique > 0) reasons.push({ code: 'unique', n: s.unique, examples: s.uniqueTitles.slice(0, 3) });
      if (s.covered > 0 && s.unique === 0) {
        const elsewhere = new Set<string>();
        for (const w of s._covered) for (const p of w.providers) if (p !== s.serviceId && ownedIds.has(p)) elsewhere.add(nameOf(p));
        reasons.push({ code: 'allElsewhere', n: s.covered, elsewhere: [...elsewhere] });
      }
      if (s.covered === 0) reasons.push({ code: 'nothingOnList' });

      if (keepIds.includes(s.sub.id)) s.verdict = 'keep';
      else if (s.usage !== null && s.usage >= 2) s.verdict = 'unsure';
      else s.verdict = 'consider';
    } else {
      if (titles.length > 0 && coverableTitles.length === 0) reasons.push({ code: 'nothingOnList' });
      if (s.usage === null) {
        s.verdict = 'unsure';
        reasons.push({ code: 'noInfo' });
      } else if (s.usage >= 2) s.verdict = 'keep';
      else if (s.usage === 1) s.verdict = 'unsure';
      else s.verdict = 'consider';
    }
    s.reasons = reasons;
  }

  const clean: ServiceAdvice[] = services.map(({ _duplicate, _covered, ...rest }) => rest);

  const order: Record<Verdict, number> = { keep: 0, unsure: 1, consider: 2 };
  clean.sort((a, b) => order[a.verdict] - order[b.verdict] || b.monthlyCents - a.monthlyCents);

  return {
    services: clean,
    totalCents,
    keepIds,
    keepCents,
    savingsCents: keepIds ? Math.max(0, totalCents - keepCents) : 0,
    coverable: coverableTitles.length,
    notCovered: titles.length - coverableTitles.length,
  };
}
