import { Cycle, PriceChange, Subscription } from './types';

/** Parse an ISO yyyy-mm-dd string as a local date (no timezone shift). */
export function parseISO(iso: string): Date {
  const [y, m, d] = iso.split('-').map(Number);
  return new Date(y, m - 1, d);
}

export function toISO(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function startOfToday(): Date {
  const n = new Date();
  return new Date(n.getFullYear(), n.getMonth(), n.getDate());
}

/**
 * Add n cycles to a date. For month-based cycles the day of month is clamped,
 * so a subscription starting on Jan 31 charges on Feb 28/29, then Mar 31.
 */
export function addCycles(start: Date, cycle: Cycle, n: number): Date {
  if (cycle === 'week') {
    return new Date(start.getFullYear(), start.getMonth(), start.getDate() + 7 * n);
  }
  const months = cycle === 'month' ? n : cycle === 'quarter' ? 3 * n : 12 * n;
  const targetMonth = start.getMonth() + months;
  const y = start.getFullYear() + Math.floor(targetMonth / 12);
  const m = ((targetMonth % 12) + 12) % 12;
  const lastDay = new Date(y, m + 1, 0).getDate();
  return new Date(y, m, Math.min(start.getDate(), lastDay));
}

/** Next charge date on or after today. */
export function nextCharge(sub: Subscription, today: Date = startOfToday()): Date {
  const start = parseISO(sub.startDate);
  if (start >= today) return start;
  // Jump close to today first, then step forward — avoids long loops for old subs.
  let n = 0;
  if (sub.cycle === 'week') {
    n = Math.floor((today.getTime() - start.getTime()) / (7 * 86400000));
  } else {
    const monthsPer = sub.cycle === 'month' ? 1 : sub.cycle === 'quarter' ? 3 : 12;
    const monthsDiff =
      (today.getFullYear() - start.getFullYear()) * 12 + (today.getMonth() - start.getMonth());
    n = Math.max(0, Math.floor(monthsDiff / monthsPer) - 1);
  }
  let d = addCycles(start, sub.cycle, n);
  while (d < today) {
    n += 1;
    d = addCycles(start, sub.cycle, n);
  }
  return d;
}

export function daysUntil(date: Date, today: Date = startOfToday()): number {
  return Math.round((date.getTime() - today.getTime()) / 86400000);
}

/** Average monthly cost in cents. */
export function monthlyCents(sub: Subscription): number {
  switch (sub.cycle) {
    case 'week':
      return (sub.amountCents * 52) / 12;
    case 'month':
      return sub.amountCents;
    case 'quarter':
      return sub.amountCents / 3;
    case 'year':
      return sub.amountCents / 12;
  }
}

export function totals(subs: Subscription[]) {
  const month = subs.reduce((acc, s) => acc + monthlyCents(s), 0);
  return { monthCents: Math.round(month), yearCents: Math.round(month * 12) };
}

// ---------- Price changes ----------

/** The price that will be charged on a given date (takes a scheduled change into account). */
export function amountOn(sub: Subscription, date: Date): number {
  const sc = sub.scheduledChange;
  if (sc && date >= parseISO(sc.date)) return sc.toCents;
  return sub.amountCents;
}

/** Set a new current price and keep a record of the old one. */
export function recordPriceChange(
  sub: Subscription,
  toCents: number,
  dateISO: string,
  source: PriceChange['source'],
): Subscription {
  if (toCents === sub.amountCents) return sub;
  const entry: PriceChange = { date: dateISO, fromCents: sub.amountCents, toCents, source };
  return {
    ...sub,
    amountCents: toCents,
    priceHistory: [...(sub.priceHistory ?? []), entry].slice(-20),
  };
}

/** Apply scheduled changes whose date has arrived. */
export function applyDueChanges(
  subs: Subscription[],
  today: Date = startOfToday(),
): { subs: Subscription[]; changed: boolean } {
  let changed = false;
  const next = subs.map((sub) => {
    const sc = sub.scheduledChange;
    if (!sc || parseISO(sc.date) > today) return sub;
    changed = true;
    return { ...recordPriceChange(sub, sc.toCents, sc.date, sc.source), scheduledChange: null };
  });
  return { subs: next, changed };
}

/** Most recent applied change within `days` days, if any. */
export function recentChange(sub: Subscription, days: number, today: Date = startOfToday()): PriceChange | null {
  const last = sub.priceHistory?.[sub.priceHistory.length - 1];
  if (!last) return null;
  return daysUntil(parseISO(last.date), today) >= -days ? last : null;
}

/** Change in average monthly cost, in cents, if all scheduled changes take effect. */
export function scheduledMonthlyDelta(subs: Subscription[]): number {
  let delta = 0;
  for (const s of subs) {
    if (!s.scheduledChange) continue;
    delta += monthlyCents({ ...s, amountCents: s.scheduledChange.toCents }) - monthlyCents(s);
  }
  return Math.round(delta);
}

export function percentChange(fromCents: number, toCents: number): number {
  if (fromCents <= 0) return 0;
  return Math.round(((toCents - fromCents) / fromCents) * 100);
}

/** Parse user-typed money like "12,99", "12.99", "€ 12" into cents. Returns null if invalid. */
export function parseMoney(input: string): number | null {
  const cleaned = input.replace(/[€\s]/g, '').replace(',', '.');
  if (!/^\d+(\.\d{1,2})?$/.test(cleaned)) return null;
  const cents = Math.round(parseFloat(cleaned) * 100);
  return cents > 0 && cents < 100_000_00 ? cents : null;
}

/** Parse "dd-mm-yyyy" or "dd/mm/yyyy" into ISO, validating the calendar date. */
export function parseUserDate(input: string): string | null {
  const m = input.trim().match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$/);
  if (!m) return null;
  const d = Number(m[1]);
  const mo = Number(m[2]);
  const y = Number(m[3]);
  const date = new Date(y, mo - 1, d);
  if (date.getFullYear() !== y || date.getMonth() !== mo - 1 || date.getDate() !== d) return null;
  return toISO(date);
}

export function formatUserDate(iso: string): string {
  const [y, m, d] = iso.split('-');
  return `${d}-${m}-${y}`;
}
