import AsyncStorage from '@react-native-async-storage/async-storage';
import { Subscription } from './types';

const SUBS_KEY = 'aboradar.subscriptions.v1';
const PREMIUM_KEY = 'aboradar.premium.v1';

export async function loadSubscriptions(): Promise<Subscription[]> {
  try {
    const raw = await AsyncStorage.getItem(SUBS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export async function saveSubscriptions(subs: Subscription[]): Promise<void> {
  await AsyncStorage.setItem(SUBS_KEY, JSON.stringify(subs));
}

/** Cached premium flag so the app works offline; the store is the source of truth. */
export async function loadPremiumCache(): Promise<boolean> {
  try {
    return (await AsyncStorage.getItem(PREMIUM_KEY)) === '1';
  } catch {
    return false;
  }
}

export async function savePremiumCache(value: boolean): Promise<void> {
  await AsyncStorage.setItem(PREMIUM_KEY, value ? '1' : '0');
}

export function newId(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
