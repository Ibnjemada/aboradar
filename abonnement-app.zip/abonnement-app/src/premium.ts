/**
 * In-app purchase for "Premium" (one-time unlock), via RevenueCat.
 *
 * Setup (see HANDLEIDING.md, stap 6):
 *  1. Create a one-time product "premium_unlock" in Google Play Console.
 *  2. Create a free RevenueCat account, add the Android app, add an
 *     entitlement called "premium" and attach the product to it.
 *  3. Paste the public Android SDK key in src/config.ts.
 *
 * Until a key is filled in, purchases report "not available" and the app
 * simply runs in the free version (5 subscriptions).
 */
import { Platform } from 'react-native';
import Purchases, { CustomerInfo, PurchasesPackage } from 'react-native-purchases';
import { REVENUECAT_ANDROID_KEY } from './config';

const ENTITLEMENT = 'premium';

let configured = false;

export function purchasesAvailable(): boolean {
  return Platform.OS === 'android' && REVENUECAT_ANDROID_KEY.length > 0;
}

function hasPremium(info: CustomerInfo): boolean {
  return Boolean(info.entitlements.active[ENTITLEMENT]);
}

export async function initPurchases(): Promise<boolean | null> {
  if (!purchasesAvailable()) return null;
  try {
    if (!configured) {
      Purchases.configure({ apiKey: REVENUECAT_ANDROID_KEY });
      configured = true;
    }
    return hasPremium(await Purchases.getCustomerInfo());
  } catch {
    return null; // offline or not set up: fall back to cached value
  }
}

async function getPackage(): Promise<PurchasesPackage | null> {
  const offerings = await Purchases.getOfferings();
  return offerings.current?.availablePackages[0] ?? null;
}

export async function getPriceString(): Promise<string | null> {
  if (!purchasesAvailable()) return null;
  try {
    const pkg = await getPackage();
    return pkg?.product.priceString ?? null;
  } catch {
    return null;
  }
}

export type PurchaseResult = 'success' | 'cancelled' | 'failed' | 'unavailable';

export async function buyPremium(): Promise<PurchaseResult> {
  if (!purchasesAvailable()) return 'unavailable';
  try {
    const pkg = await getPackage();
    if (!pkg) return 'unavailable';
    const { customerInfo } = await Purchases.purchasePackage(pkg);
    return hasPremium(customerInfo) ? 'success' : 'failed';
  } catch (e: any) {
    if (e?.userCancelled) return 'cancelled';
    return 'failed';
  }
}

export async function restorePremium(): Promise<boolean | null> {
  if (!purchasesAvailable()) return null;
  try {
    return hasPremium(await Purchases.restorePurchases());
  } catch {
    return null;
  }
}
