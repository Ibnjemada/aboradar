import { useColorScheme } from 'react-native';

const light = {
  bg: '#F4F6F5',
  card: '#FFFFFF',
  text: '#0F1A17',
  muted: '#5B6B66',
  border: '#E2E8E6',
  primary: '#0F766E',
  primaryText: '#FFFFFF',
  hero: '#0F766E',
  heroText: '#FFFFFF',
  heroMuted: '#B7E4DE',
  danger: '#DC2626',
  dangerBg: '#FEE2E2',
  good: '#15803D',
  goodBg: '#DCFCE7',
  warn: '#B45309',
  warnBg: '#FEF3C7',
  inputBg: '#F8FAF9',
};

export type Theme = typeof light;

const dark: Theme = {
  bg: '#0B1211',
  card: '#151F1D',
  text: '#E8F0EE',
  muted: '#93A6A0',
  border: '#24322F',
  primary: '#2DD4BF',
  primaryText: '#04201C',
  hero: '#123A35',
  heroText: '#FFFFFF',
  heroMuted: '#8FD3C9',
  danger: '#F87171',
  dangerBg: '#3B1212',
  good: '#4ADE80',
  goodBg: '#0D2E1A',
  warn: '#FBBF24',
  warnBg: '#3A2A08',
  inputBg: '#0F1816',
};

export function useTheme(): Theme {
  return useColorScheme() === 'dark' ? dark : light;
}
