export type Cycle = 'week' | 'month' | 'quarter' | 'year';

export type Category =
  | 'streaming'
  | 'music'
  | 'software'
  | 'sport'
  | 'insurance'
  | 'telecom'
  | 'news'
  | 'other';

/** How often the user says they use a service (streaming advisor). */
export type Usage = 'daily' | 'weekly' | 'monthly' | 'rarely';

/** A price change that has already taken effect. */
export interface PriceChange {
  /** ISO yyyy-mm-dd the new price took effect. */
  date: string;
  fromCents: number;
  toCents: number;
  source: 'user' | 'feed';
}

/** A price change that is announced but not yet in effect. */
export interface ScheduledChange {
  date: string;
  toCents: number;
  source: 'user' | 'feed';
  /** Id of the feed announcement, when it came from the price feed. */
  feedId?: string;
}

export interface Subscription {
  id: string;
  name: string;
  /** Current amount per cycle, in cents (avoids rounding errors). */
  amountCents: number;
  cycle: Cycle;
  /** First/known charge date, ISO yyyy-mm-dd. Future charges are derived from it. */
  startDate: string;
  category: Category;
  /** Days before a charge to send a reminder. -1 = no reminder. */
  remindDaysBefore: number;
  createdAt: number;

  /** Catalog service id (e.g. 'netflix') when picked from the list. */
  serviceId?: string;
  /** Catalog plan id (e.g. 'netflix-standard'). */
  planId?: string;
  /** Past price changes, oldest first. */
  priceHistory?: PriceChange[];
  /** Upcoming price change, applied automatically on its date. */
  scheduledChange?: ScheduledChange | null;
  /** Feed announcements the user chose to ignore. */
  dismissedFeedIds?: string[];
  /** Self-reported usage, for the streaming advisor. */
  usage?: Usage;
}

export const CATEGORY_COLORS: Record<Category, string> = {
  streaming: '#E11D48',
  music: '#16A34A',
  software: '#2563EB',
  sport: '#EA580C',
  insurance: '#7C3AED',
  telecom: '#0891B2',
  news: '#475569',
  other: '#A16207',
};

export const CATEGORY_ICONS: Record<Category, string> = {
  streaming: '🎬',
  music: '🎵',
  software: '💻',
  sport: '🏋️',
  insurance: '🛡️',
  telecom: '📱',
  news: '📰',
  other: '📦',
};

export const FREE_LIMIT = 5;
