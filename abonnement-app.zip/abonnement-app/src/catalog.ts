/**
 * Catalog of known services with their current Dutch prices, plus announced
 * price changes. A copy ships inside the app (catalog-data.ts); an updated
 * version can be downloaded from PRICE_FEED_URL (see feed.ts).
 *
 * Everything in this file is pure logic (no device APIs), so it can be tested.
 */
import { parseISO, recordPriceChange, startOfToday } from './calc';
import { Category, Cycle, Subscription } from './types';

export interface CatalogPlan {
  id: string;
  name: string;
  cents: number;
  cycle: Cycle;
}

export interface CatalogService {
  id: string;
  name: string;
  category: Category;
  /** Film/series streaming service: included in the streaming advisor. */
  streaming: boolean;
  /** Android package names, for automatic usage measuring. */
  androidPackages?: string[];
  /** TMDB watch-provider ids. */
  tmdbProviderIds?: number[];
  /** Lowercase name fragments to match TMDB provider names. Prefix "=" for an exact match. */
  providerNames?: string[];
  plans: CatalogPlan[];
}

/** An announced price change for one plan, published through the price feed. */
export interface FeedAnnouncement {
  /** Unique id, never reuse. E.g. "netflix-standard-2026-11". */
  id: string;
  planId: string;
  /** ISO date the new price takes effect. */
  date: string;
  toCents: number;
  note?: string;
}

export interface PriceFeed {
  /** Increase every time you edit the online feed. */
  version: number;
  /** ISO date of the last price check. */
  updated: string;
  services: CatalogService[];
  announcements: FeedAnnouncement[];
}

export function isValidFeed(f: unknown): f is PriceFeed {
  if (!f || typeof f !== 'object') return false;
  const o = f as PriceFeed;
  return (
    typeof o.version === 'number' &&
    Array.isArray(o.services) &&
    Array.isArray(o.announcements) &&
    o.services.every(
      (s) => typeof s.id === 'string' && typeof s.name === 'string' && Array.isArray(s.plans) &&
        s.plans.every((p) => typeof p.id === 'string' && typeof p.cents === 'number'),
    ) &&
    o.announcements.every(
      (a) => typeof a.id === 'string' && typeof a.planId === 'string' &&
        /^\d{4}-\d{2}-\d{2}$/.test(a.date) && typeof a.toCents === 'number',
    )
  );
}

export function findService(feed: PriceFeed, id?: string): CatalogService | undefined {
  return id ? feed.services.find((s) => s.id === id) : undefined;
}

export function findPlan(feed: PriceFeed, planId?: string): { service: CatalogService; plan: CatalogPlan } | undefined {
  if (!planId) return undefined;
  for (const service of feed.services) {
    const plan = service.plans.find((p) => p.id === planId);
    if (plan) return { service, plan };
  }
  return undefined;
}

function normalize(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
}

/**
 * Which catalog service a subscription belongs to: the one picked from the list,
 * or a name match for subscriptions typed in by hand ("netflix" → Netflix).
 */
export function resolveServiceId(sub: Subscription, feed: PriceFeed): string | undefined {
  if (sub.serviceId && findService(feed, sub.serviceId)) return sub.serviceId;
  const name = normalize(sub.name);
  if (!name) return undefined;
  for (const s of feed.services) {
    const loose = [s.name, ...(s.providerNames ?? []).filter((p) => !p.startsWith('='))]
      .map(normalize)
      .filter((c) => c.length >= 3);
    const exact = (s.providerNames ?? []).filter((p) => p.startsWith('=')).map((p) => normalize(p.slice(1)));
    if (loose.some((c) => name.includes(c)) || exact.includes(name)) return s.id;
  }
  return undefined;
}

/** Map a TMDB watch provider to a catalog service id. Add-on "channels" are ignored. */
export function matchProvider(feed: PriceFeed, providerId: number, providerName: string): string | undefined {
  const n = providerName.toLowerCase();
  if (n.includes('channel')) return undefined;
  for (const s of feed.services) {
    if (s.tmdbProviderIds?.includes(providerId)) return s.id;
  }
  for (const s of feed.services) {
    for (const p of s.providerNames ?? []) {
      if (p.startsWith('=') ? n === p.slice(1) : n.includes(p)) return s.id;
    }
  }
  return undefined;
}

export interface PendingAnnouncement {
  sub: Subscription;
  announcement: FeedAnnouncement;
  fromCents: number;
}

/** Announced price changes that apply to the user's subscriptions and still need a decision. */
export function pendingAnnouncements(
  subs: Subscription[],
  feed: PriceFeed,
  today: Date = startOfToday(),
): PendingAnnouncement[] {
  const oldest = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 60);
  const result: PendingAnnouncement[] = [];
  for (const sub of subs) {
    if (!sub.planId) continue;
    for (const a of feed.announcements) {
      if (a.planId !== sub.planId) continue;
      if (parseISO(a.date) < oldest) continue;
      if (sub.dismissedFeedIds?.includes(a.id)) continue;
      if (sub.scheduledChange?.feedId === a.id) continue;
      if (sub.amountCents === a.toCents) continue;
      if (sub.scheduledChange && sub.scheduledChange.toCents === a.toCents) continue;
      if (sub.priceHistory?.some((h) => h.toCents === a.toCents && h.date === a.date)) continue;
      result.push({ sub, announcement: a, fromCents: sub.amountCents });
    }
  }
  return result.sort((x, y) => x.announcement.date.localeCompare(y.announcement.date));
}

/** User accepts an announcement: schedule it, or apply it right away if the date has passed. */
export function acceptAnnouncement(sub: Subscription, a: FeedAnnouncement, today: Date = startOfToday()): Subscription {
  if (parseISO(a.date) <= today) {
    return { ...recordPriceChange(sub, a.toCents, a.date, 'feed'), scheduledChange: null };
  }
  return { ...sub, scheduledChange: { date: a.date, toCents: a.toCents, source: 'feed', feedId: a.id } };
}

export function dismissAnnouncement(sub: Subscription, a: FeedAnnouncement): Subscription {
  return { ...sub, dismissedFeedIds: [...(sub.dismissedFeedIds ?? []), a.id].slice(-30) };
}

/** Cheapest plan price of a service, for "from €x" in the picker. */
export function fromPrice(service: CatalogService): CatalogPlan | undefined {
  return [...service.plans].sort((a, b) => a.cents - b.cents)[0];
}
