import AsyncStorage from '@react-native-async-storage/async-storage';
import { isValidFeed, PriceFeed } from './catalog';
import { BUNDLED_FEED } from './catalog-data';
import { PRICE_FEED_URL } from './config';

const CACHE_KEY = 'aboradar.feed.v1';

/**
 * Returns the newest price feed available: the online one when reachable,
 * otherwise the last downloaded copy, otherwise the built-in list.
 */
export async function loadFeed(): Promise<PriceFeed> {
  let best: PriceFeed = BUNDLED_FEED;

  try {
    const raw = await AsyncStorage.getItem(CACHE_KEY);
    if (raw) {
      const cached = JSON.parse(raw);
      if (isValidFeed(cached) && cached.version > best.version) best = cached;
    }
  } catch {
    // ignore a broken cache
  }

  if (PRICE_FEED_URL) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    try {
      const res = await fetch(PRICE_FEED_URL, { signal: controller.signal, headers: { 'Cache-Control': 'no-cache' } });
      if (res.ok) {
        const remote = await res.json();
        if (isValidFeed(remote) && remote.version >= best.version) {
          best = remote;
          await AsyncStorage.setItem(CACHE_KEY, JSON.stringify(remote));
        }
      }
    } catch {
      // offline: keep what we have
    } finally {
      clearTimeout(timer);
    }
  }

  return best;
}

export { BUNDLED_FEED };
