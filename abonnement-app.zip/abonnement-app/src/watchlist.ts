/**
 * Watchlist: films and series the user wants to watch, with the streaming
 * services they are available on in the Netherlands.
 * Data: TMDB API (availability data by JustWatch). Key in src/config.ts.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import { WatchItem } from './advisor';
import { matchProvider, PriceFeed } from './catalog';
import { TMDB_READ_TOKEN, WATCH_REGION } from './config';

const STORAGE_KEY = 'aboradar.watchlist.v1';
const API = 'https://api.themoviedb.org/3';
const IMG = 'https://image.tmdb.org/t/p/w92';
const MAX_ITEMS = 100;
const REFRESH_AFTER_MS = 7 * 86400000;

export interface SearchResult {
  key: string;
  tmdbId: number;
  type: 'movie' | 'tv';
  title: string;
  year?: string;
  poster?: string | null;
}

export function watchDataAvailable(): boolean {
  return TMDB_READ_TOKEN.length > 0;
}

export function posterUrl(path?: string | null): string | null {
  return path ? `${IMG}${path}` : null;
}

async function tmdb(path: string, params: Record<string, string> = {}): Promise<any> {
  const qs = Object.entries(params)
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
    .join('&');
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10000);
  try {
    const res = await fetch(`${API}${path}${qs ? `?${qs}` : ''}`, {
      headers: { Authorization: `Bearer ${TMDB_READ_TOKEN}`, accept: 'application/json' },
      signal: controller.signal,
    });
    if (!res.ok) throw new Error(`TMDB ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

export async function searchTitles(query: string, language: string): Promise<SearchResult[]> {
  const q = query.trim();
  if (q.length < 2 || !watchDataAvailable()) return [];
  const data = await tmdb('/search/multi', { query: q, language, include_adult: 'false', page: '1' });
  const results: any[] = Array.isArray(data?.results) ? data.results : [];
  return results
    .filter((r) => r.media_type === 'movie' || r.media_type === 'tv')
    .slice(0, 12)
    .map((r) => {
      const type = r.media_type as 'movie' | 'tv';
      const date: string | undefined = type === 'movie' ? r.release_date : r.first_air_date;
      return {
        key: `${type}:${r.id}`,
        tmdbId: r.id,
        type,
        title: (type === 'movie' ? r.title : r.name) ?? '?',
        year: date ? date.slice(0, 4) : undefined,
        poster: r.poster_path ?? null,
      };
    });
}

/** Catalog service ids where a title is included in a subscription (flat-rate or with ads). */
export async function fetchProviders(type: 'movie' | 'tv', id: number, feed: PriceFeed): Promise<string[]> {
  const data = await tmdb(`/${type}/${id}/watch/providers`);
  const region = data?.results?.[WATCH_REGION];
  const list: any[] = [...(region?.flatrate ?? []), ...(region?.ads ?? [])];
  const ids = new Set<string>();
  for (const p of list) {
    const match = matchProvider(feed, Number(p.provider_id), String(p.provider_name ?? ''));
    if (match) ids.add(match);
  }
  return [...ids];
}

export async function toWatchItem(r: SearchResult, feed: PriceFeed): Promise<WatchItem> {
  const providers = await fetchProviders(r.type, r.tmdbId, feed);
  return { ...r, providers, checkedAt: Date.now() };
}

/** Availability changes over time: re-check titles older than a week. */
export async function refreshStale(items: WatchItem[], feed: PriceFeed): Promise<{ items: WatchItem[]; changed: boolean }> {
  if (!watchDataAvailable()) return { items, changed: false };
  let changed = false;
  const next: WatchItem[] = [];
  for (const item of items) {
    if (Date.now() - item.checkedAt < REFRESH_AFTER_MS) {
      next.push(item);
      continue;
    }
    try {
      const providers = await fetchProviders(item.type, item.tmdbId, feed);
      next.push({ ...item, providers, checkedAt: Date.now() });
      changed = true;
    } catch {
      next.push(item); // offline: keep the old data
    }
  }
  return { items: next, changed };
}

export async function loadWatchlist(): Promise<WatchItem[]> {
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export async function saveWatchlist(items: WatchItem[]): Promise<void> {
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(items.slice(0, MAX_ITEMS)));
}
