import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { t } from '../i18n';
import { buyPremium, getPriceString, restorePremium } from '../premium';
import { useTheme } from '../theme';

interface Props {
  isPremium: boolean;
  reason?: 'limit' | 'advisor';
  onUnlocked: () => void;
  onClose: () => void;
}

export function PremiumScreen({ isPremium, reason, onUnlocked, onClose }: Props) {
  const c = useTheme();
  const insets = useSafeAreaInsets();
  const [price, setPrice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    getPriceString().then(setPrice);
  }, []);

  const buy = async () => {
    setBusy(true);
    const result = await buyPremium();
    setBusy(false);
    if (result === 'success') onUnlocked();
    else if (result === 'failed') Alert.alert(t.purchaseFailed);
    else if (result === 'unavailable') Alert.alert(t.purchaseUnavailable);
  };

  const restore = async () => {
    setBusy(true);
    const ok = await restorePremium();
    setBusy(false);
    if (ok) onUnlocked();
    else Alert.alert(ok === null ? t.purchaseUnavailable : t.restoredNone);
  };

  return (
    <View style={[styles.container, { backgroundColor: c.bg, paddingTop: insets.top + 12, paddingBottom: insets.bottom + 24 }]}>
      <Pressable onPress={onClose} hitSlop={12} style={styles.close} accessibilityLabel={t.close}>
        <Text style={[styles.closeText, { color: c.muted }]}>✕</Text>
      </Pressable>

      <View style={styles.center}>
        <Text style={styles.star}>⭐</Text>
        <Text style={[styles.title, { color: c.text }]}>{t.premiumTitle}</Text>
        <Text style={[styles.sub, { color: c.muted }]}>{isPremium ? t.premiumActive : t.premiumSub}</Text>

        {reason && !isPremium && (
          <View style={[styles.notice, { backgroundColor: c.warnBg }]}>
            <Text style={[styles.noticeText, { color: c.warn }]}>
              {reason === 'limit' ? t.limitReached : t.advisorLocked}
            </Text>
          </View>
        )}

        <View style={[styles.card, { backgroundColor: c.card, borderColor: c.border }]}>
          {t.premiumFeatures.map((f) => (
            <View key={f} style={styles.featureRow}>
              <Text style={[styles.check, { color: c.primary }]}>✓</Text>
              <Text style={[styles.feature, { color: c.text }]}>{f}</Text>
            </View>
          ))}
        </View>
      </View>

      {!isPremium && (
        <View>
          <Pressable
            onPress={buy}
            disabled={busy}
            style={[styles.buyBtn, { backgroundColor: c.primary, opacity: busy ? 0.6 : 1 }]}
          >
            {busy ? (
              <ActivityIndicator color={c.primaryText} />
            ) : (
              <Text style={[styles.buyText, { color: c.primaryText }]}>{t.buy(price ?? '€ 3,99')}</Text>
            )}
          </Pressable>
          <Pressable onPress={restore} disabled={busy} style={styles.restoreBtn}>
            <Text style={[styles.restoreText, { color: c.muted }]}>{t.restore}</Text>
          </Pressable>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 24, justifyContent: 'space-between' },
  close: { alignSelf: 'flex-end', padding: 4 },
  closeText: { fontSize: 22 },
  center: { alignItems: 'center' },
  star: { fontSize: 56, marginBottom: 12 },
  title: { fontSize: 26, fontWeight: '800', textAlign: 'center' },
  sub: { fontSize: 16, marginTop: 6, textAlign: 'center' },
  notice: { marginTop: 18, borderRadius: 12, padding: 12 },
  noticeText: { fontSize: 14, fontWeight: '600', textAlign: 'center' },
  card: { alignSelf: 'stretch', borderWidth: 1, borderRadius: 18, padding: 18, marginTop: 24 },
  featureRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8 },
  check: { fontSize: 18, fontWeight: '800', width: 28 },
  feature: { fontSize: 16, flex: 1 },
  buyBtn: { borderRadius: 16, paddingVertical: 18, alignItems: 'center' },
  buyText: { fontSize: 18, fontWeight: '700' },
  restoreBtn: { paddingVertical: 14, alignItems: 'center' },
  restoreText: { fontSize: 15 },
});
