import React, { useMemo, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { isStreamingSub } from '../advisor';
import { PendingAnnouncement, PriceFeed } from '../catalog';
import { ChangesCard } from '../components/ChangesCard';
import { Chip } from '../components/Chip';
import { SubscriptionRow } from '../components/SubscriptionRow';
import { monthlyCents, nextCharge, scheduledMonthlyDelta, totals } from '../calc';
import { money, moneyDelta, t } from '../i18n';
import { useTheme } from '../theme';
import { CATEGORY_COLORS, CATEGORY_ICONS, Category, FREE_LIMIT, Subscription } from '../types';

type Sort = 'next' | 'price' | 'name';

interface Props {
  subs: Subscription[];
  feed: PriceFeed;
  pending: PendingAnnouncement[];
  isPremium: boolean;
  onAdd: () => void;
  onEdit: (sub: Subscription) => void;
  onOpenPremium: () => void;
  onOpenAdvisor: () => void;
  onAcceptAnnouncement: (p: PendingAnnouncement) => void;
  onIgnoreAnnouncement: (p: PendingAnnouncement) => void;
}

export function HomeScreen({
  subs,
  feed,
  pending,
  isPremium,
  onAdd,
  onEdit,
  onOpenPremium,
  onOpenAdvisor,
  onAcceptAnnouncement,
  onIgnoreAnnouncement,
}: Props) {
  const c = useTheme();
  const insets = useSafeAreaInsets();
  const [sort, setSort] = useState<Sort>('next');

  const { monthCents, yearCents } = useMemo(() => totals(subs), [subs]);
  const delta = useMemo(() => scheduledMonthlyDelta(subs), [subs]);
  const streaming = useMemo(() => subs.filter((s) => isStreamingSub(s, feed)), [subs, feed]);
  const streamingCents = Math.round(streaming.reduce((acc, s) => acc + monthlyCents(s), 0));

  const sorted = useMemo(() => {
    const list = [...subs];
    if (sort === 'next') list.sort((a, b) => nextCharge(a).getTime() - nextCharge(b).getTime());
    if (sort === 'price') list.sort((a, b) => monthlyCents(b) - monthlyCents(a));
    if (sort === 'name') list.sort((a, b) => a.name.localeCompare(b.name));
    return list;
  }, [subs, sort]);

  const byCategory = useMemo(() => {
    const map = new Map<Category, number>();
    for (const s of subs) map.set(s.category, (map.get(s.category) ?? 0) + monthlyCents(s));
    return [...map.entries()].sort((a, b) => b[1] - a[1]);
  }, [subs]);

  const header = (
    <View>
      <View style={[styles.hero, { backgroundColor: c.hero, paddingTop: insets.top + 16 }]}>
        <View style={styles.heroTop}>
          <Text style={[styles.appName, { color: c.heroText }]}>{t.appName}</Text>
          <Pressable onPress={onOpenPremium} hitSlop={10} style={[styles.premiumPill, { borderColor: c.heroMuted }]}>
            <Text style={[styles.premiumPillText, { color: c.heroText }]}>{isPremium ? '★ ' : ''}{t.premium}</Text>
          </Pressable>
        </View>
        <Text style={[styles.total, { color: c.heroText }]}>{money(monthCents)}</Text>
        <Text style={[styles.totalLabel, { color: c.heroMuted }]}>{t.perMonth}</Text>
        <View style={[styles.yearBox, { backgroundColor: 'rgba(255,255,255,0.12)' }]}>
          <Text style={[styles.yearText, { color: c.heroText }]}>
            {money(yearCents)} <Text style={{ color: c.heroMuted }}>{t.perYear}</Text>
          </Text>
        </View>
        {delta !== 0 && (
          <Text style={[styles.delta, { color: c.heroText }]}>
            {delta > 0 ? '↑' : '↓'} {t.heroDelta(moneyDelta(delta))}
          </Text>
        )}
      </View>

      {subs.length > 0 && (
        <View style={styles.section}>
          <ChangesCard
            subs={subs}
            pending={pending}
            onAccept={onAcceptAnnouncement}
            onIgnore={onIgnoreAnnouncement}
            onOpen={onEdit}
          />

          {streaming.length >= 2 && (
            <Pressable
              onPress={onOpenAdvisor}
              style={({ pressed }) => [
                styles.teaser,
                { backgroundColor: c.card, borderColor: c.primary, opacity: pressed ? 0.8 : 1 },
              ]}
            >
              <Text style={styles.teaserIcon}>🎬</Text>
              <View style={{ flex: 1 }}>
                <Text style={[styles.teaserTitle, { color: c.text }]}>{t.teaserTitle(streaming.length)}</Text>
                <Text style={[styles.teaserBody, { color: c.muted }]}>{t.teaserBody(money(streamingCents))}</Text>
              </View>
              <Text style={[styles.teaserArrow, { color: c.primary }]}>{isPremium ? '›' : '★'}</Text>
            </Pressable>
          )}
          {isPremium && byCategory.length > 1 && (
            <View style={[styles.catCard, { backgroundColor: c.card, borderColor: c.border }]}>
              <Text style={[styles.sectionTitle, { color: c.text, marginBottom: 10 }]}>{t.byCategory}</Text>
              <View style={styles.barTrack}>
                {byCategory.map(([cat, cents]) => (
                  <View
                    key={cat}
                    style={{ flex: cents, backgroundColor: CATEGORY_COLORS[cat], height: 10 }}
                  />
                ))}
              </View>
              {byCategory.map(([cat, cents]) => (
                <View key={cat} style={styles.catRow}>
                  <Text style={[styles.catName, { color: c.text }]}>
                    {CATEGORY_ICONS[cat]}  {t.categories[cat]}
                  </Text>
                  <Text style={[styles.catAmount, { color: c.muted }]}>{money(Math.round(cents))}{t.cyclesShort.month}</Text>
                </View>
              ))}
            </View>
          )}

          <View style={styles.listHeader}>
            <Text style={[styles.sectionTitle, { color: c.text }]}>{t.yourSubs}</Text>
            <Text style={[styles.count, { color: c.muted }]}>
              {isPremium ? subs.length : `${subs.length}/${FREE_LIMIT}`}
            </Text>
          </View>
          <View style={styles.chips}>
            <Chip label={t.sortNext} selected={sort === 'next'} onPress={() => setSort('next')} />
            <Chip label={t.sortPrice} selected={sort === 'price'} onPress={() => setSort('price')} />
            <Chip label={t.sortName} selected={sort === 'name'} onPress={() => setSort('name')} />
          </View>
        </View>
      )}
    </View>
  );

  return (
    <View style={[styles.container, { backgroundColor: c.bg }]}>
      <FlatList
        data={sorted}
        keyExtractor={(s) => s.id}
        ListHeaderComponent={header}
        renderItem={({ item }) => (
          <View style={styles.rowWrap}>
            <SubscriptionRow sub={item} onPress={() => onEdit(item)} />
          </View>
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyEmoji}>🔍</Text>
            <Text style={[styles.emptyText, { color: c.muted }]}>{t.empty}</Text>
          </View>
        }
        ListFooterComponent={
          subs.length >= 2 ? (
            <Text style={[styles.tip, { color: c.muted }]}>
              💡 {t.savingsTip(money(Math.round(Math.max(...subs.map(monthlyCents)) * 12)))}
            </Text>
          ) : null
        }
        contentContainerStyle={{ paddingBottom: insets.bottom + 110 }}
      />

      <Pressable
        onPress={onAdd}
        accessibilityRole="button"
        accessibilityLabel={t.add}
        style={({ pressed }) => [
          styles.fab,
          { backgroundColor: c.primary, bottom: insets.bottom + 24, transform: [{ scale: pressed ? 0.95 : 1 }] },
        ]}
      >
        <Text style={[styles.fabText, { color: c.primaryText }]}>+</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  hero: { paddingHorizontal: 20, paddingBottom: 24, borderBottomLeftRadius: 28, borderBottomRightRadius: 28 },
  heroTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  appName: { fontSize: 18, fontWeight: '700', letterSpacing: 0.3 },
  premiumPill: { borderWidth: 1, borderRadius: 999, paddingHorizontal: 12, paddingVertical: 5 },
  premiumPillText: { fontSize: 13, fontWeight: '600' },
  total: { fontSize: 44, fontWeight: '800', fontVariant: ['tabular-nums'] },
  totalLabel: { fontSize: 15, marginTop: 2 },
  yearBox: { alignSelf: 'flex-start', marginTop: 16, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 8 },
  yearText: { fontSize: 15, fontWeight: '600' },
  delta: { fontSize: 13, fontWeight: '600', marginTop: 10 },
  teaser: { flexDirection: 'row', alignItems: 'center', borderWidth: 1.5, borderRadius: 16, padding: 14, marginBottom: 20 },
  teaserIcon: { fontSize: 26, marginRight: 12 },
  teaserTitle: { fontSize: 16, fontWeight: '700' },
  teaserBody: { fontSize: 13, marginTop: 2 },
  teaserArrow: { fontSize: 24, fontWeight: '700', marginLeft: 8 },
  section: { paddingHorizontal: 16, paddingTop: 20 },
  sectionTitle: { fontSize: 17, fontWeight: '700' },
  listHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 10 },
  count: { fontSize: 14 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: 4 },
  rowWrap: { paddingHorizontal: 16 },
  catCard: { borderWidth: 1, borderRadius: 16, padding: 14, marginBottom: 20 },
  barTrack: { flexDirection: 'row', borderRadius: 5, overflow: 'hidden', marginBottom: 10 },
  catRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 4 },
  catName: { fontSize: 14 },
  catAmount: { fontSize: 14, fontVariant: ['tabular-nums'] },
  empty: { alignItems: 'center', paddingTop: 60, paddingHorizontal: 32 },
  emptyEmoji: { fontSize: 48, marginBottom: 12 },
  emptyText: { fontSize: 16, textAlign: 'center', lineHeight: 24 },
  tip: { fontSize: 13, textAlign: 'center', paddingHorizontal: 32, marginTop: 8, lineHeight: 19 },
  fab: {
    position: 'absolute',
    right: 20,
    width: 62,
    height: 62,
    borderRadius: 31,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 6,
    shadowColor: '#000',
    shadowOpacity: 0.25,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
  },
  fabText: { fontSize: 32, fontWeight: '400', marginTop: -2 },
});
