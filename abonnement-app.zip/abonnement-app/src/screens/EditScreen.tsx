import React, { useMemo, useState } from 'react';
import {
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Chip } from '../components/Chip';
import {
  formatUserDate,
  parseISO,
  parseMoney,
  parseUserDate,
  percentChange,
  recordPriceChange,
  startOfToday,
  toISO,
} from '../calc';
import { CatalogService, findService, fromPrice, PriceFeed } from '../catalog';
import { longDate, money, t } from '../i18n';
import { newId } from '../storage';
import { useTheme } from '../theme';
import { CATEGORY_ICONS, Category, Cycle, ScheduledChange, Subscription, Usage } from '../types';

const CYCLES: Cycle[] = ['month', 'year', 'quarter', 'week'];
const CATEGORIES: Category[] = ['streaming', 'music', 'software', 'sport', 'insurance', 'telecom', 'news', 'other'];
const REMINDERS = [-1, 0, 1, 3, 7];
const USAGES: Usage[] = ['daily', 'weekly', 'monthly', 'rarely'];

interface Props {
  initial: Subscription | null;
  feed: PriceFeed;
  onSave: (sub: Subscription) => void;
  onDelete: (id: string) => void;
  onClose: () => void;
}

const decimalSep = t.amountPh.includes(',') ? ',' : '.';
const centsToInput = (cents: number) => (cents / 100).toFixed(2).replace('.', decimalSep);

function firstOfNextMonth(): string {
  const d = startOfToday();
  return toISO(new Date(d.getFullYear(), d.getMonth() + 1, 1));
}

export function EditScreen({ initial, feed, onSave, onDelete, onClose }: Props) {
  const c = useTheme();
  const insets = useSafeAreaInsets();

  const [step, setStep] = useState<'pick' | 'form'>(initial ? 'form' : 'pick');
  const [query, setQuery] = useState('');

  const [serviceId, setServiceId] = useState<string | undefined>(initial?.serviceId);
  const [planId, setPlanId] = useState<string | undefined>(initial?.planId);
  const [name, setName] = useState(initial?.name ?? '');
  const [amount, setAmount] = useState(initial ? centsToInput(initial.amountCents) : '');
  const [cycle, setCycle] = useState<Cycle>(initial?.cycle ?? 'month');
  const [date, setDate] = useState(formatUserDate(initial?.startDate ?? toISO(startOfToday())));
  const [category, setCategory] = useState<Category>(initial?.category ?? 'streaming');
  const [remind, setRemind] = useState(initial?.remindDaysBefore ?? 1);
  const [usage, setUsage] = useState<Usage | undefined>(initial?.usage);
  const [error, setError] = useState<string | null>(null);

  // Upcoming price change
  const [existingSc, setExistingSc] = useState<ScheduledChange | null>(initial?.scheduledChange ?? null);
  const [showFuture, setShowFuture] = useState(false);
  const [futureAmount, setFutureAmount] = useState('');
  const [futureDate, setFutureDate] = useState(formatUserDate(firstOfNextMonth()));

  const service = findService(feed, serviceId);
  const plan = service?.plans.find((p) => p.id === planId);
  const parsedAmount = parseMoney(amount);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return feed.services.filter((s) => !q || s.name.toLowerCase().includes(q));
  }, [feed, query]);

  const pickService = (s: CatalogService) => {
    const defaultPlan = s.plans.length === 3 ? s.plans[1] : s.plans[0];
    setServiceId(s.id);
    setName(s.name);
    setCategory(s.category);
    if (defaultPlan) {
      setPlanId(defaultPlan.id);
      setAmount(centsToInput(defaultPlan.cents));
      setCycle(defaultPlan.cycle);
    }
    setStep('form');
  };

  const pickCustom = () => {
    setServiceId(undefined);
    setPlanId(undefined);
    setName(query.trim());
    setAmount('');
    setCategory('other');
    setStep('form');
  };

  const selectPlan = (id: string) => {
    const p = service?.plans.find((x) => x.id === id);
    if (!p) return;
    setPlanId(p.id);
    setAmount(centsToInput(p.cents));
    setCycle(p.cycle);
    setError(null);
  };

  const save = () => {
    const trimmed = name.trim();
    if (!trimmed) return setError(t.errName);
    const cents = parseMoney(amount);
    if (cents === null) return setError(t.errAmount);
    const iso = parseUserDate(date);
    if (!iso) return setError(t.errDate);

    let futureCents: number | null = null;
    let futureISO: string | null = null;
    if (showFuture) {
      futureCents = parseMoney(futureAmount);
      if (futureCents === null || futureCents === cents) return setError(t.errNewPrice);
      futureISO = parseUserDate(futureDate);
      if (!futureISO) return setError(t.errEffectiveDate);
    }

    const base: Subscription = {
      ...(initial ?? {}),
      id: initial?.id ?? newId(),
      createdAt: initial?.createdAt ?? Date.now(),
      name: trimmed.slice(0, 40),
      amountCents: initial ? initial.amountCents : cents,
      cycle,
      startDate: iso,
      category,
      remindDaysBefore: remind,
      serviceId,
      planId,
      usage: category === 'streaming' ? usage : undefined,
      scheduledChange: existingSc,
    };

    const finish = (priceChanged: boolean) => {
      let sub = base;
      if (initial && cents !== initial.amountCents) {
        sub = priceChanged
          ? recordPriceChange(sub, cents, toISO(startOfToday()), 'user')
          : { ...sub, amountCents: cents };
      }
      if (futureCents !== null && futureISO) {
        if (parseISO(futureISO) <= startOfToday()) {
          sub = { ...recordPriceChange(sub, futureCents, futureISO, 'user'), scheduledChange: null };
        } else {
          sub = { ...sub, scheduledChange: { date: futureISO, toCents: futureCents, source: 'user' } };
        }
      }
      onSave(sub);
    };

    if (initial && cents !== initial.amountCents) {
      Alert.alert(t.priceChangedQ, t.priceChangedBody(money(initial.amountCents), money(cents)), [
        { text: t.cancel, style: 'cancel' },
        { text: t.noTypo, onPress: () => finish(false) },
        { text: t.yesChanged, onPress: () => finish(true) },
      ]);
    } else {
      finish(false);
    }
  };

  const confirmDelete = () => {
    if (!initial) return;
    Alert.alert(t.deleteConfirm(initial.name), undefined, [
      { text: t.cancel, style: 'cancel' },
      { text: t.delete, style: 'destructive', onPress: () => onDelete(initial.id) },
    ]);
  };

  const inputStyle = [styles.input, { backgroundColor: c.inputBg, borderColor: c.border, color: c.text }];

  // ---------- Step 1: choose a service ----------
  if (step === 'pick') {
    return (
      <View style={[styles.container, { backgroundColor: c.bg }]}>
        <View style={[styles.topBar, { paddingTop: insets.top + 8, borderBottomColor: c.border }]}>
          <Pressable onPress={onClose} hitSlop={12}>
            <Text style={[styles.topAction, { color: c.muted }]}>{t.cancel}</Text>
          </Pressable>
          <Text style={[styles.topTitle, { color: c.text }]}>{t.pickService}</Text>
          <View style={{ width: 60 }} />
        </View>
        <FlatList
          data={filtered}
          keyExtractor={(s) => s.id}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 40 }}
          ListHeaderComponent={
            <View>
              <TextInput
                value={query}
                onChangeText={setQuery}
                placeholder={t.searchService}
                placeholderTextColor={c.muted}
                style={[inputStyle, { marginBottom: 12 }]}
                autoFocus
              />
              <Pressable
                onPress={pickCustom}
                style={[styles.serviceRow, { backgroundColor: c.card, borderColor: c.primary }]}
              >
                <Text style={styles.serviceIcon}>✏️</Text>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.serviceName, { color: c.primary }]}>{t.customSub}</Text>
                  <Text style={[styles.servicePrice, { color: c.muted }]}>{t.customSubHint}</Text>
                </View>
              </Pressable>
            </View>
          }
          renderItem={({ item }) => {
            const cheapest = fromPrice(item);
            return (
              <Pressable
                onPress={() => pickService(item)}
                style={({ pressed }) => [
                  styles.serviceRow,
                  { backgroundColor: c.card, borderColor: c.border, opacity: pressed ? 0.7 : 1 },
                ]}
              >
                <Text style={styles.serviceIcon}>{CATEGORY_ICONS[item.category]}</Text>
                <Text style={[styles.serviceName, { color: c.text, flex: 1 }]}>{item.name}</Text>
                {cheapest && (
                  <Text style={[styles.servicePrice, { color: c.muted }]}>
                    {t.fromPrice(money(cheapest.cents))}
                    {t.cyclesShort[cheapest.cycle]}
                  </Text>
                )}
              </Pressable>
            );
          }}
        />
      </View>
    );
  }

  // ---------- Step 2: details ----------
  return (
    <KeyboardAvoidingView
      style={[styles.container, { backgroundColor: c.bg }]}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={[styles.topBar, { paddingTop: insets.top + 8, borderBottomColor: c.border }]}>
        <Pressable onPress={initial ? onClose : () => setStep('pick')} hitSlop={12}>
          <Text style={[styles.topAction, { color: c.muted }]}>{initial ? t.cancel : `‹ ${t.back}`}</Text>
        </Pressable>
        <Text style={[styles.topTitle, { color: c.text }]}>{initial ? t.edit : t.add}</Text>
        <Pressable onPress={save} hitSlop={12}>
          <Text style={[styles.topAction, { color: c.primary, fontWeight: '700' }]}>{t.save}</Text>
        </Pressable>
      </View>

      <ScrollView
        contentContainerStyle={[styles.body, { paddingBottom: insets.bottom + 40 }]}
        keyboardShouldPersistTaps="handled"
      >
        {error && (
          <Text style={[styles.error, { color: c.danger }]} accessibilityLiveRegion="polite">
            {error}
          </Text>
        )}

        <Text style={[styles.label, { color: c.muted }]}>{t.name}</Text>
        <TextInput
          value={name}
          onChangeText={(v) => {
            setName(v);
            setError(null);
          }}
          placeholder={t.namePh}
          placeholderTextColor={c.muted}
          style={inputStyle}
          maxLength={40}
          autoFocus={!initial && !serviceId}
        />

        {service && service.plans.length > 0 && (
          <>
            <Text style={[styles.label, { color: c.muted }]}>{t.plan}</Text>
            <View style={styles.chips}>
              {service.plans.map((p) => (
                <Chip
                  key={p.id}
                  label={`${p.name} · ${money(p.cents)}${t.cyclesShort[p.cycle]}`}
                  selected={planId === p.id}
                  onPress={() => selectPlan(p.id)}
                />
              ))}
            </View>
          </>
        )}

        <Text style={[styles.label, { color: c.muted }]}>{t.amount}</Text>
        <TextInput
          value={amount}
          onChangeText={(v) => {
            setAmount(v);
            setError(null);
          }}
          placeholder={t.amountPh}
          placeholderTextColor={c.muted}
          keyboardType="decimal-pad"
          style={inputStyle}
        />
        {plan && parsedAmount !== null && parsedAmount !== plan.cents && (
          <View style={[styles.hint, { backgroundColor: c.warnBg }]}>
            <Text style={[styles.hintText, { color: c.warn }]}>{t.catalogPrice(plan.name, money(plan.cents))}</Text>
            <Pressable onPress={() => setAmount(centsToInput(plan.cents))} hitSlop={8}>
              <Text style={[styles.hintAction, { color: c.warn }]}>{t.useCatalogPrice}</Text>
            </Pressable>
          </View>
        )}

        <Text style={[styles.label, { color: c.muted }]}>{t.cycle}</Text>
        <View style={styles.chips}>
          {CYCLES.map((cy) => (
            <Chip key={cy} label={t.cycles[cy]} selected={cycle === cy} onPress={() => setCycle(cy)} />
          ))}
        </View>

        <Text style={[styles.label, { color: c.muted }]}>{t.firstDate}</Text>
        <TextInput
          value={date}
          onChangeText={(v) => {
            setDate(v);
            setError(null);
          }}
          placeholder={t.datePh}
          placeholderTextColor={c.muted}
          keyboardType="numbers-and-punctuation"
          style={inputStyle}
          maxLength={10}
        />

        <Text style={[styles.label, { color: c.muted }]}>{t.category}</Text>
        <View style={styles.chips}>
          {CATEGORIES.map((cat) => (
            <Chip
              key={cat}
              label={`${CATEGORY_ICONS[cat]} ${t.categories[cat]}`}
              selected={category === cat}
              onPress={() => setCategory(cat)}
            />
          ))}
        </View>

        {category === 'streaming' && (
          <>
            <Text style={[styles.label, { color: c.muted }]}>{t.usageQ}</Text>
            <View style={styles.chips}>
              {USAGES.map((u) => (
                <Chip
                  key={u}
                  label={t.usages[u]}
                  selected={usage === u}
                  onPress={() => setUsage(usage === u ? undefined : u)}
                />
              ))}
            </View>
          </>
        )}

        <Text style={[styles.label, { color: c.muted }]}>{t.reminder}</Text>
        <View style={styles.chips}>
          {REMINDERS.map((r) => (
            <Chip
              key={r}
              label={r < 0 ? t.noReminder : t.daysBefore(r)}
              selected={remind === r}
              onPress={() => setRemind(r)}
            />
          ))}
        </View>

        {initial && (
          <>
            <Text style={[styles.label, { color: c.muted }]}>{t.futureChange}</Text>
            {existingSc && !showFuture ? (
              <View style={[styles.box, { backgroundColor: c.card, borderColor: c.border }]}>
                <Text
                  style={[
                    styles.boxText,
                    { color: existingSc.toCents > initial.amountCents ? c.danger : c.good },
                  ]}
                >
                  {existingSc.toCents > initial.amountCents ? '↑' : '↓'}{' '}
                  {t.rowScheduled(money(existingSc.toCents), longDate(parseISO(existingSc.date)))}
                </Text>
                <Pressable onPress={() => setExistingSc(null)} hitSlop={8}>
                  <Text style={[styles.hintAction, { color: c.danger }]}>{t.delete}</Text>
                </Pressable>
              </View>
            ) : showFuture ? (
              <View style={[styles.boxCol, { backgroundColor: c.card, borderColor: c.border }]}>
                <Text style={[styles.smallLabel, { color: c.muted }]}>{t.newPrice}</Text>
                <TextInput
                  value={futureAmount}
                  onChangeText={(v) => {
                    setFutureAmount(v);
                    setError(null);
                  }}
                  placeholder={t.amountPh}
                  placeholderTextColor={c.muted}
                  keyboardType="decimal-pad"
                  style={inputStyle}
                />
                <Text style={[styles.smallLabel, { color: c.muted }]}>{t.effectiveDate}</Text>
                <TextInput
                  value={futureDate}
                  onChangeText={(v) => {
                    setFutureDate(v);
                    setError(null);
                  }}
                  placeholder={t.datePh}
                  placeholderTextColor={c.muted}
                  keyboardType="numbers-and-punctuation"
                  style={inputStyle}
                  maxLength={10}
                />
                <Pressable onPress={() => setShowFuture(false)} style={{ marginTop: 10 }} hitSlop={8}>
                  <Text style={[styles.hintAction, { color: c.muted }]}>{t.cancel}</Text>
                </Pressable>
              </View>
            ) : (
              <Pressable onPress={() => setShowFuture(true)} hitSlop={8}>
                <Text style={[styles.link, { color: c.primary }]}>{t.addFutureChange}</Text>
              </Pressable>
            )}

            {initial.priceHistory && initial.priceHistory.length > 0 && (
              <>
                <Text style={[styles.label, { color: c.muted }]}>{t.history}</Text>
                <View style={[styles.boxCol, { backgroundColor: c.card, borderColor: c.border }]}>
                  {[...initial.priceHistory].reverse().map((h, i) => {
                    const pct = percentChange(h.fromCents, h.toCents);
                    const up = h.toCents > h.fromCents;
                    return (
                      <View key={`${h.date}-${i}`} style={styles.historyRow}>
                        <Text style={[styles.historyDate, { color: c.muted }]}>{longDate(parseISO(h.date))}</Text>
                        <Text style={[styles.historyText, { color: c.text }]}>
                          {money(h.fromCents)} → {money(h.toCents)}{' '}
                          <Text style={{ color: up ? c.danger : c.good }}>
                            ({pct > 0 ? '+' : ''}
                            {pct}%)
                          </Text>
                        </Text>
                      </View>
                    );
                  })}
                </View>
              </>
            )}
          </>
        )}

        <Pressable style={[styles.saveBtn, { backgroundColor: c.primary }]} onPress={save}>
          <Text style={[styles.saveText, { color: c.primaryText }]}>{t.save}</Text>
        </Pressable>

        {initial && (
          <Pressable style={styles.deleteBtn} onPress={confirmDelete}>
            <Text style={[styles.deleteText, { color: c.danger }]}>{t.delete}</Text>
          </Pressable>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  topTitle: { fontSize: 17, fontWeight: '700' },
  topAction: { fontSize: 16, minWidth: 60 },
  body: { padding: 16 },
  label: { fontSize: 13, fontWeight: '600', marginTop: 18, marginBottom: 8, textTransform: 'uppercase', letterSpacing: 0.5 },
  smallLabel: { fontSize: 13, fontWeight: '600', marginTop: 4, marginBottom: 6 },
  input: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, fontSize: 17 },
  chips: { flexDirection: 'row', flexWrap: 'wrap' },
  error: { fontSize: 15, fontWeight: '600', marginBottom: 4 },
  hint: { flexDirection: 'row', alignItems: 'center', borderRadius: 10, padding: 10, marginTop: 8 },
  hintText: { flex: 1, fontSize: 13 },
  hintAction: { fontSize: 14, fontWeight: '700', marginLeft: 10 },
  box: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderRadius: 12, padding: 12 },
  boxCol: { borderWidth: 1, borderRadius: 12, padding: 12 },
  boxText: { flex: 1, fontSize: 15, fontWeight: '600' },
  link: { fontSize: 15, fontWeight: '600', paddingVertical: 6 },
  historyRow: { paddingVertical: 6 },
  historyDate: { fontSize: 12 },
  historyText: { fontSize: 15, marginTop: 1 },
  serviceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 14,
    padding: 14,
    marginBottom: 8,
  },
  serviceIcon: { fontSize: 22, marginRight: 12 },
  serviceName: { fontSize: 16, fontWeight: '600' },
  servicePrice: { fontSize: 13 },
  saveBtn: { marginTop: 28, borderRadius: 14, paddingVertical: 16, alignItems: 'center' },
  saveText: { fontSize: 17, fontWeight: '700' },
  deleteBtn: { marginTop: 12, paddingVertical: 14, alignItems: 'center' },
  deleteText: { fontSize: 16, fontWeight: '600' },
});
