import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  AppState,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  getForegroundMinutes,
  hasUsagePermission,
  openUsageSettings,
  usageMeasuringAvailable,
} from '../../modules/usage-stats';
import { buildAdvice, isStreamingSub, Reason, Verdict, WatchItem } from '../advisor';
import { findService, PriceFeed, resolveServiceId } from '../catalog';
import { Chip } from '../components/Chip';
import { money, t } from '../i18n';
import { Theme, useTheme } from '../theme';
import { Subscription, Usage } from '../types';
import {
  loadWatchlist,
  posterUrl,
  refreshStale,
  saveWatchlist,
  searchTitles,
  SearchResult,
  toWatchItem,
  watchDataAvailable,
} from '../watchlist';

const USAGES: Usage[] = ['daily', 'weekly', 'monthly', 'rarely'];

interface Props {
  subs: Subscription[];
  feed: PriceFeed;
  onUpdateSub: (sub: Subscription) => void;
  onClose: () => void;
}

function reasonText(r: Reason): string {
  switch (r.code) {
    case 'usage':
      return r.minutes !== null ? t.reasonMeasured(t.duration(r.minutes)) : t.reasonLevel[r.level];
    case 'unique':
      return t.reasonUnique(r.n, r.examples);
    case 'allElsewhere':
      return t.reasonElsewhere(r.n, r.elsewhere);
    case 'nothingOnList':
      return t.reasonNothing;
    case 'duplicate':
      return t.reasonDuplicate;
    case 'noInfo':
      return t.reasonNoInfo;
  }
}

function verdictColors(v: Verdict, c: Theme) {
  if (v === 'keep') return { fg: c.good, bg: c.goodBg };
  if (v === 'consider') return { fg: c.danger, bg: c.dangerBg };
  return { fg: c.warn, bg: c.warnBg };
}

export function AdvisorScreen({ subs, feed, onUpdateSub, onClose }: Props) {
  const c = useTheme();
  const insets = useSafeAreaInsets();

  const [watchlist, setWatchlist] = useState<WatchItem[]>([]);
  const [autoMinutes, setAutoMinutes] = useState<Record<string, number> | null>(null);
  const [permission, setPermission] = useState(false);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState(false);
  const [adding, setAdding] = useState<string | null>(null);

  const streamingSubs = useMemo(() => subs.filter((s) => isStreamingSub(s, feed)), [subs, feed]);
  const ownedIds = useMemo(
    () => new Set(streamingSubs.map((s) => resolveServiceId(s, feed)).filter(Boolean) as string[]),
    [streamingSubs, feed],
  );
  const packages = useMemo(() => {
    const all = new Set<string>();
    ownedIds.forEach((id) => findService(feed, id)?.androidPackages?.forEach((p) => all.add(p)));
    return [...all];
  }, [ownedIds, feed]);
  const packagesKey = packages.join(',');

  // Measured watch time (Android, with permission). Re-checked when returning from Settings.
  const measure = useCallback(() => {
    if (!usageMeasuringAvailable()) return;
    const granted = hasUsagePermission();
    setPermission(granted);
    setAutoMinutes(granted ? getForegroundMinutes(packages, 30) : null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [packagesKey]);

  useEffect(() => {
    measure();
    const listener = AppState.addEventListener('change', (state) => {
      if (state === 'active') measure();
    });
    return () => listener.remove();
  }, [measure]);

  // Watchlist: load, then refresh availability that is more than a week old.
  useEffect(() => {
    let alive = true;
    (async () => {
      const items = await loadWatchlist();
      if (!alive) return;
      setWatchlist(items);
      const refreshed = await refreshStale(items, feed);
      if (alive && refreshed.changed) {
        setWatchlist(refreshed.items);
        saveWatchlist(refreshed.items);
      }
    })();
    return () => {
      alive = false;
    };
  }, [feed]);

  // Search with a short delay while typing.
  useEffect(() => {
    const q = query.trim();
    setSearchError(false);
    if (q.length < 2) {
      setResults([]);
      setSearching(false);
      return;
    }
    setSearching(true);
    const timer = setTimeout(() => {
      searchTitles(q, t.tmdbLanguage)
        .then(setResults)
        .catch(() => setSearchError(true))
        .finally(() => setSearching(false));
    }, 400);
    return () => clearTimeout(timer);
  }, [query]);

  const addTitle = async (r: SearchResult) => {
    setAdding(r.key);
    try {
      const item = await toWatchItem(r, feed);
      const next = [item, ...watchlist.filter((w) => w.key !== item.key)];
      setWatchlist(next);
      saveWatchlist(next);
      setQuery('');
    } catch {
      setSearchError(true);
    } finally {
      setAdding(null);
    }
  };

  const removeTitle = (key: string) => {
    const next = watchlist.filter((w) => w.key !== key);
    setWatchlist(next);
    saveWatchlist(next);
  };

  const advice = useMemo(() => buildAdvice(subs, feed, watchlist, autoMinutes), [subs, feed, watchlist, autoMinutes]);
  const keepNames = advice.keepIds
    ? advice.services.filter((s) => advice.keepIds!.includes(s.sub.id)).map((s) => s.sub.name)
    : [];
  const watchEnabled = watchDataAvailable();

  return (
    <View style={[styles.container, { backgroundColor: c.bg }]}>
      <View style={[styles.topBar, { paddingTop: insets.top + 8, borderBottomColor: c.border }]}>
        <Pressable onPress={onClose} hitSlop={12} accessibilityLabel={t.close}>
          <Text style={[styles.close, { color: c.muted }]}>✕</Text>
        </Pressable>
        <Text style={[styles.topTitle, { color: c.text }]}>{t.advisorTitle}</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView
        contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 40 }}
        keyboardShouldPersistTaps="handled"
      >
        {/* Summary */}
        <View style={[styles.summary, { backgroundColor: c.hero }]}>
          <Text style={[styles.summaryLead, { color: c.heroText }]}>
            {t.youPay(money(advice.totalCents), advice.services.length)}
          </Text>
          {advice.keepIds && (
            <>
              <Text style={[styles.summaryAdvice, { color: c.heroText }]}>{t.adviceKeep(keepNames)}</Text>
              <Text style={[styles.summaryText, { color: c.heroMuted }]}>
                {advice.savingsCents > 0
                  ? t.adviceSavings(money(advice.savingsCents), money(advice.savingsCents * 12))
                  : t.adviceAllNeeded}
              </Text>
            </>
          )}
          {advice.notCovered > 0 && (
            <Text style={[styles.summaryText, { color: c.heroMuted }]}>{t.adviceNotCovered(advice.notCovered)}</Text>
          )}
          {watchEnabled && watchlist.length === 0 && (
            <Text style={[styles.summaryText, { color: c.heroMuted }]}>{t.adviceAddWatchlist}</Text>
          )}
        </View>

        {/* Automatic usage measuring */}
        {usageMeasuringAvailable() &&
          (permission ? (
            <Text style={[styles.autoOn, { color: c.muted }]}>✓ {t.autoOn}</Text>
          ) : (
            <View style={[styles.card, { backgroundColor: c.card, borderColor: c.border }]}>
              <Text style={[styles.cardTitle, { color: c.text }]}>⏱️ {t.autoTitle}</Text>
              <Text style={[styles.cardText, { color: c.muted }]}>{t.autoBody}</Text>
              <Pressable onPress={openUsageSettings} style={[styles.primaryBtn, { backgroundColor: c.primary }]}>
                <Text style={[styles.primaryBtnText, { color: c.primaryText }]}>{t.autoButton}</Text>
              </Pressable>
              <Text style={[styles.hint, { color: c.muted }]}>{t.autoHint}</Text>
            </View>
          ))}

        {/* Per service */}
        {advice.services.map((s) => {
          const colors = verdictColors(s.verdict, c);
          return (
            <View key={s.sub.id} style={[styles.card, { backgroundColor: c.card, borderColor: c.border }]}>
              <View style={styles.serviceHeader}>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.serviceName, { color: c.text }]}>{s.sub.name}</Text>
                  <Text style={[styles.serviceCost, { color: c.muted }]}>
                    {money(s.monthlyCents)}
                    {t.cyclesShort.month}
                  </Text>
                </View>
                <View style={[styles.pill, { backgroundColor: colors.bg }]}>
                  <Text style={[styles.pillText, { color: colors.fg }]}>{t.verdicts[s.verdict]}</Text>
                </View>
              </View>
              {s.reasons.map((r, i) => (
                <Text key={i} style={[styles.reason, { color: c.text }]}>
                  • {reasonText(r)}
                </Text>
              ))}
              <Text style={[styles.smallLabel, { color: c.muted }]}>{t.usageQ}</Text>
              <View style={styles.chips}>
                {USAGES.map((u) => (
                  <Chip
                    key={u}
                    label={t.usages[u]}
                    selected={s.sub.usage === u}
                    onPress={() => onUpdateSub({ ...s.sub, usage: s.sub.usage === u ? undefined : u })}
                  />
                ))}
              </View>
            </View>
          );
        })}

        {/* Watchlist */}
        {watchEnabled && (
          <View style={{ marginTop: 12 }}>
            <Text style={[styles.sectionTitle, { color: c.text }]}>🍿 {t.watchlistTitle}</Text>
            <Text style={[styles.cardText, { color: c.muted, marginBottom: 10 }]}>{t.watchlistBody}</Text>
            <TextInput
              value={query}
              onChangeText={setQuery}
              placeholder={t.searchTitles}
              placeholderTextColor={c.muted}
              style={[styles.input, { backgroundColor: c.inputBg, borderColor: c.border, color: c.text }]}
              returnKeyType="search"
            />
            {searching && <ActivityIndicator style={{ marginTop: 12 }} color={c.primary} />}
            {searchError && <Text style={[styles.hint, { color: c.danger }]}>{t.searchFailed}</Text>}
            {!searching && !searchError && query.trim().length >= 2 && results.length === 0 && (
              <Text style={[styles.hint, { color: c.muted }]}>{t.noResults}</Text>
            )}
            {results.map((r) => {
              const already = watchlist.some((w) => w.key === r.key);
              const poster = posterUrl(r.poster);
              return (
                <Pressable
                  key={r.key}
                  disabled={already || adding !== null}
                  onPress={() => addTitle(r)}
                  style={[styles.titleRow, { borderBottomColor: c.border }]}
                >
                  {poster ? (
                    <Image source={{ uri: poster }} style={styles.poster} />
                  ) : (
                    <View style={[styles.poster, { backgroundColor: c.border }]} />
                  )}
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.titleName, { color: c.text }]} numberOfLines={1}>
                      {r.title}
                    </Text>
                    <Text style={[styles.titleMeta, { color: c.muted }]}>
                      {r.type === 'tv' ? '📺' : '🎬'} {r.year ?? ''}
                    </Text>
                  </View>
                  {adding === r.key ? (
                    <ActivityIndicator color={c.primary} />
                  ) : (
                    <Text style={[styles.addText, { color: already ? c.muted : c.primary }]}>
                      {already ? t.added : '+'}
                    </Text>
                  )}
                </Pressable>
              );
            })}

            {watchlist.map((w) => {
              const poster = posterUrl(w.poster);
              return (
                <View key={w.key} style={[styles.card, styles.watchItem, { backgroundColor: c.card, borderColor: c.border }]}>
                  {poster ? (
                    <Image source={{ uri: poster }} style={styles.poster} />
                  ) : (
                    <View style={[styles.poster, { backgroundColor: c.border }]} />
                  )}
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.titleName, { color: c.text }]} numberOfLines={1}>
                      {w.title} {w.year ? <Text style={{ color: c.muted, fontWeight: '400' }}>({w.year})</Text> : null}
                    </Text>
                    {w.providers.length === 0 ? (
                      <Text style={[styles.titleMeta, { color: c.muted }]}>{t.notStreaming}</Text>
                    ) : (
                      <View style={styles.providerRow}>
                        {w.providers.map((p) => {
                          const owned = ownedIds.has(p);
                          return (
                            <View
                              key={p}
                              style={[
                                styles.provider,
                                { borderColor: owned ? c.primary : c.border, backgroundColor: owned ? c.primary + '1A' : 'transparent' },
                              ]}
                            >
                              <Text style={[styles.providerText, { color: owned ? c.primary : c.muted }]}>
                                {findService(feed, p)?.name ?? p}
                              </Text>
                            </View>
                          );
                        })}
                      </View>
                    )}
                  </View>
                  <Pressable onPress={() => removeTitle(w.key)} hitSlop={10} accessibilityLabel={t.delete}>
                    <Text style={[styles.remove, { color: c.muted }]}>✕</Text>
                  </Pressable>
                </View>
              );
            })}
          </View>
        )}

        <Text style={[styles.tip, { color: c.muted }]}>💡 {t.rotationTip}</Text>
        {watchEnabled && <Text style={[styles.attribution, { color: c.muted }]}>{t.attribution}</Text>}
      </ScrollView>
    </View>
  );
}


const styles = StyleSheet.create({
  container: { flex: 1 },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  topTitle: { fontSize: 17, fontWeight: '700' },
  close: { fontSize: 22, width: 24 },
  summary: { borderRadius: 18, padding: 18, marginBottom: 16 },
  summaryLead: { fontSize: 16, fontWeight: '600' },
  summaryAdvice: { fontSize: 20, fontWeight: '800', marginTop: 10 },
  summaryText: { fontSize: 14, marginTop: 6, lineHeight: 20 },
  autoOn: { fontSize: 13, marginBottom: 12 },
  card: { borderWidth: 1, borderRadius: 16, padding: 14, marginBottom: 12 },
  cardTitle: { fontSize: 16, fontWeight: '700', marginBottom: 6 },
  cardText: { fontSize: 14, lineHeight: 20 },
  primaryBtn: { borderRadius: 12, paddingVertical: 12, alignItems: 'center', marginTop: 12 },
  primaryBtnText: { fontSize: 15, fontWeight: '700' },
  hint: { fontSize: 13, marginTop: 8, lineHeight: 18 },
  serviceHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  serviceName: { fontSize: 17, fontWeight: '700' },
  serviceCost: { fontSize: 13, marginTop: 2 },
  pill: { borderRadius: 999, paddingHorizontal: 10, paddingVertical: 5 },
  pillText: { fontSize: 13, fontWeight: '700' },
  reason: { fontSize: 14, lineHeight: 20, marginTop: 2 },
  smallLabel: { fontSize: 12, fontWeight: '600', marginTop: 12, marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.5 },
  chips: { flexDirection: 'row', flexWrap: 'wrap' },
  sectionTitle: { fontSize: 18, fontWeight: '800', marginBottom: 4 },
  input: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, fontSize: 16, marginBottom: 6 },
  titleRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8, borderBottomWidth: StyleSheet.hairlineWidth },
  poster: { width: 40, height: 60, borderRadius: 6, marginRight: 12 },
  titleName: { fontSize: 15, fontWeight: '600' },
  titleMeta: { fontSize: 13, marginTop: 3 },
  addText: { fontSize: 22, fontWeight: '700', paddingHorizontal: 8 },
  watchItem: { flexDirection: 'row', alignItems: 'center', padding: 10, marginTop: 10, marginBottom: 0 },
  providerRow: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 6 },
  provider: { borderWidth: 1, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3, marginRight: 6, marginBottom: 4 },
  providerText: { fontSize: 12, fontWeight: '600' },
  remove: { fontSize: 18, paddingLeft: 10 },
  tip: { fontSize: 13, lineHeight: 19, marginTop: 20 },
  attribution: { fontSize: 11, lineHeight: 16, marginTop: 12 },
});
